﻿Public Class Form1

    Dim x, y As Integer
    Dim newPoint As New Point

    Dim NbrItem As Integer = 0

    Public themeColor As Color = Color.FromArgb(255, 88, 88)

    Public nickName As String = "Customer"
    Public lIIllIIlIllIIlIl As Boolean = False

    Public clicked1 As Boolean = False

    Private Sub Label1_Click(sender As Object, e As EventArgs) Handles Label1.Click
        On Error Resume Next
        Close()
    End Sub

    Private Sub Label2_Click(sender As Object, e As EventArgs) Handles Label2.Click
        WindowState = FormWindowState.Minimized
    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        On Error Resume Next

        SessionManager.IllIllIIlIlIIllI.Navigate("https://darkness143config.weebly.com/")
        SessionManager.IIlIIIllIlIlIlIlII()

        'THEME
        If Not IO.File.Exists(Application.StartupPath & "\theme.txt") Then
            UpdateTheme()
        Else
            Dim SR As New IO.StreamReader(Application.StartupPath & "\theme.txt")
            Dim theme As String = SR.ReadToEnd
            SR.Close()

            If theme.Contains("bleu") Then
                themeColor = Color.DodgerBlue
                PictureBox1.Image = My.Resources.logoblue
            End If

            If theme.Contains("violet") Then
                themeColor = Color.MediumSlateBlue
                PictureBox1.Image = My.Resources.logo
            End If

            If theme.Contains("vert") Then
                themeColor = Color.LimeGreen
                PictureBox1.Image = My.Resources.logogreen
            End If

            If theme.Contains("gris") Then
                themeColor = Color.DarkGray
                PictureBox1.Image = My.Resources.logogray
            End If

            If theme.Contains("orange") Then
                themeColor = Color.Orange
                PictureBox1.Image = My.Resources.logoorange
            End If

            UpdateTheme()
        End If


        'CHARGER LES CRASHERS
        AddCrasher("KATANA1", "⚔️", "Simple Crasher", "5 1500", "crash,katana1", CrasherPanel, 0, 0)
        AddCrasher("VENUS1", "🪐", "ExploitFixer Bypass", "250 700 1 500", "crash,venus1", CrasherPanel, 1, 0)
        AddCrasher("VENUS2", "🪐", "ExploitFixer Bypass", "250 700 1 500", "crash,venus2", CrasherPanel, 2, 0)
        AddCrasher("NEPTUNA1", "💦", "LPX Bypass", "250 1", "crash,neptuna1", CrasherPanel, 3, 0)
        AddCrasher("NEPTUNA2", "💦", "LPX Bypass", "250 1", "crash,neptuna2", CrasherPanel, 4, 0)
        AddCrasher("NEPTUNA3", "💦", "LPX Bypass", "5 1500", "crash,neptuna3", CrasherPanel, 5, 0)
        AddCrasher("JUPITER1", "🪐", "LPX Bypass", "1 10 25 10 15000 200", "crash,jupiter1", CrasherPanel, 6, 0)
        AddCrasher("JUPITER2", "🪐", "SpigotGuard Bypass", "25", "crash,jupiter2", CrasherPanel, 7, 0)
        AddCrasher("JUPITER3", "🪐", "SpigotGuard Bypass", "100", "crash,jupiter3", CrasherPanel, 8, 0)
        AddCrasher("SHARK1", "💦", "1.16+ Crasher", "15000 250 15 15", "crash,shark1", CrasherPanel, 9, 0)
        AddCrasher("SHARK2", "💦", "Advanced NettyCrasher", "10 5 80", "crash,shark2", CrasherPanel, 10, 0)
        AddCrasher("STORM1", "🌩️", "Simple Crasher with bots", "5000", "crash,storm1", CrasherPanel, 11, 0)
        AddCrasher("STORM2", "🌩️", "Instant Crasher", "100", "crash,storm2", CrasherPanel, 12, 0)
        AddCrasher("JELLY1", "❤️", "Simple bypass", "850 25 500 90 1", "crash,jelly1", CrasherPanel, 13, 0)
        AddCrasher("SNAIL1", "🌳", "Ultimate NettyCrasher", "500", "crash,snail1", CrasherPanel, 14, 0)
        AddCrasher("TIGER1", "🐈‍", "OnePacket Crasher", "100", "crash,tiger1", CrasherPanel, 15, 0)
        AddCrasher("WHALE1", "🐟", "CPU-Overloader Crasher", "54 500 1000 2000", "crash,whale1", CrasherPanel, 16, 0)
        AddCrasher("CAMEL1", "🐫", "BlockPlace Crasher", "25", "crash,camel1", CrasherPanel, 17, 0)
        AddCrasher("GOLEM1", "🧱", "WindowClick Crasher", "5", "crash,golem1", CrasherPanel, 18, 0)
        AddCrasher("BIOME1", "🌍", "1.16+ Crasher", "1500", "crash,biome1", CrasherPanel, 19, 0)
        AddCrasher("BIOME2", "🌍", "ConsoleLog Crasher", "100", "crash,biome2", CrasherPanel, 20, 0)
        AddCrasher("ZEBRA1", "🐎", "MassChunkLoad Crasher", "5", "crash,zebra1", CrasherPanel, 21, 0)
        AddCrasher("ZEBRA2", "🐎", "Old ExploitFixer Bypass", "250 10 1000", "crash,zebra2", CrasherPanel, 22, 0)
        AddCrasher("STEAK1", "🥩", "SwapSlot Crasher", "100", "crash,steak1", CrasherPanel, 23, 0)
        AddCrasher("MOHAI1", "🗿", "ExploitFixer Crasher", "1500 700 25", "crash,mohai1", CrasherPanel, 24, 0)
        AddCrasher("CLOUD1", "☁️", "CryptoClick Crasher", "3000 12", "crash,cloud1", CrasherPanel, 25, 0)
        AddCrasher("CLOUD2", "☁️", "ByteEdit Crasher", "2500 5 100", "crash,cloud2", CrasherPanel, 26, 0)
        AddCrasher("CLOUD3", "☁️", "ByteGive Crasher", "2500", "crash,cloud3", CrasherPanel, 27, 0)
        AddCrasher("CLOUD4", "☁️", "LPX Crasher (Big packet)", "50", "crash,cloud4", CrasherPanel, 28, 0)
        AddCrasher("CLOUD5", "☁️", "LPX Crasher (One packet)", "1", "crash,cloud5", CrasherPanel, 29, 0)
        AddCrasher("SALMON1", "🐟", "SpigotGuard Crasher", "250 10 500", "crash,salmon1", CrasherPanel, 30, 0)
        AddCrasher("SALMON2", "🐟", "Invalid BlockPlace Crasher", "1500 900 5", "crash,salmon2", CrasherPanel, 31, 0)
        AddCrasher("SALMON3", "🐟", "Unicode Crasher", "100", "crash,salmon3", CrasherPanel, 32, 0)
        AddCrasher("SHADOW1", "🔥", "Old SpigotGuard, ExploitFixer and CustomPayloadFixer Bypass", "15000 12", "crash,shadow1", CrasherPanel, 33, 0)
        AddCrasher("SHADOW2", "🔥", "LPX Crasher", "2500", "crash,shadow2", CrasherPanel, 34, 0)
        AddCrasher("SHADOW3", "🔥", "LPX Crasher", "100 8", "crash,shadow3", CrasherPanel, 35, 0)
        AddCrasher("BLOCK1", "🧊", "MVC-Regex Crasher (Multiverse-CoreFix Bypass)", "5 1500", "crash,block1", CrasherPanel, 36, 0)
        AddCrasher("YOSHI1", "🐢", "Invalid Book-Payload Crasher", "100", "crash,yoshi1", CrasherPanel, 37, 0)
        AddCrasher("YOSHI2", "🐢", "Vanilla-Bed Crasher", "1500", "crash,yoshi2", CrasherPanel, 38, 0)
        AddCrasher("YOSHI3", "🐢", "MathOverflow Crasher", "1500", "crash,yoshi3", CrasherPanel, 39, 0)
        AddCrasher("YOSHI4", "🐢", "PositionLook Crasher", "5", "crash,yoshi4", CrasherPanel, 40, 0)
        AddCrasher("TAIPAN1", "🐍", "HeightLimit Crasher", "1500 25", "crash,taipan1", CrasherPanel, 41, 0)
        AddCrasher("MARKI1", "🌩️", "LPX Crasher", "25", "crash,marki1", CrasherPanel, 42, 0)
        AddCrasher("MARKI2", "🌩️", "Dig Crasher (LPX-Handler Crasher)", "40 60 500", "crash,marki2", CrasherPanel, 43, 0)
        AddCrasher("MARKI3", "🌩️", "AAC5 Crasher", "100", "crash,marki3", CrasherPanel, 44, 0)
        AddCrasher("TAIKO1", "⚡", "Hypixel Crasher", "25", "crash,taiko1", CrasherPanel, 45, 0)
        AddCrasher("TAIKO2", "⚡", "TeamHoly Crasher", "5 1500", "crash,taiko2", CrasherPanel, 46, 0)
        AddCrasher("FLOPPA1", "⛏️", "PikaNetwork Crasher", "5000 6000", "crash,floppa1", CrasherPanel, 47, 0)
        AddCrasher("ALPACA1", "🦙", "JH_AntiCrashExploits Crasher", "100", "crash,alpaca1", CrasherPanel, 48, 0)
        AddCrasher("THUNDER1", "⚡", "Ultimate LPX Crasher (Big Packet)", "100", "crash,thunder1", CrasherPanel, 49, 0)
        AddCrasher("THUNDER2", "⚡", "Ultimate LPX Crasher (Small Packet)", "100", "crash,thunder2", CrasherPanel, 50, 0)
        AddCrasher("THUNDER3", "⚡", "Ultimate LPX Crasher (Cycle)", "100 250 1200", "crash,thunder3", CrasherPanel, 51, 0)
        AddCrasher("KOALA1", "🌿", "Old CoralMC Crasher", "300", "crash,koala1", CrasherPanel, 52, 0)

        'CHARGER LES EXPLOITS
        AddCrasher("REDSTONE LAG", "🔥", "Crash the server by sending 1 million of lever interaction packets", "", "exploit,redstonelag", ExploitPanel, 0, 1)
        AddCrasher("AUTHME BYPASS", "🔑", "Bypass old Authme versions", "", "exploit,authme", ExploitPanel, 1, 1)
        AddCrasher("AUTHME BYPASS #2", "🔑", "Bypass old Authme versions", "", "exploit,authbridge", ExploitPanel, 2, 1)
        AddCrasher("PEX BYPASS", "🪪", "ForceOP using a PermissionsEX exploit", "", "exploit,pexbypass", ExploitPanel, 3, 1)
        AddCrasher("PEX CRASHER", "⛏️", "Crash the server using a PermissionsEX exploit", "", "exploit,pexcrasher", ExploitPanel, 4, 1)
        AddCrasher("ENTITY CRASHER", "🔥", "You need to look at a npc to crash the server", "", "exploit,entityex", ExploitPanel, 5, 1)
        AddCrasher("ESSENTIALS CRASHER", "⚔️", "Crash the server using an Essentials exploit", "", "exploit,essentialscrasher", ExploitPanel, 6, 1)
        AddCrasher("PAY CRASHER", "⚔️", "Crash the server using a /pay exploit", "", "exploit,paycrasher", ExploitPanel, 7, 1)
        AddCrasher("CHAT CRASHER", "🔥", "Crash the server using an InteractiveChat exploit", "", "exploit,chatcrasher", ExploitPanel, 8, 1)
        AddCrasher("FRIENDS CRASHER", "❤️", "Crash the server using a /friends exploit", "", "exploit,friendscrasher", ExploitPanel, 9, 1)
        AddCrasher("REPLAY CRASHER", "🔥", "Crash the server using a /replay exploit", "", "exploit,replaycrasher", ExploitPanel, 10, 1)
        AddCrasher("NICKNAME CRASHER", "🐈‍", "Crash the server using a /nick exploit", "", "exploit,nickcrasher", ExploitPanel, 11, 1)
        AddCrasher("SKILL CRASHER", "⛏️", "Crash the server using a /skill exploit", "", "exploit,skillcrasher", ExploitPanel, 12, 1)
        AddCrasher("AAC CRASHER", "🔥", "Crash the server using an AAC exploit", "", "exploit,aaccrasher", ExploitPanel, 13, 1)
        AddCrasher("FLY CRASHER", "🪶", "Crash the server with fly", "", "exploit,flycrasher", ExploitPanel, 14, 1)
        AddCrasher("CREATIVE LAG", "⛏️", "Lag the server using a Creative exploit (can crash the server)", "", "exploit,creativelag", ExploitPanel, 15, 1)
        AddCrasher("LP BUNGEE", "⚡", "Crash the server using a LuckPerms exploit", "", "exploit,lpb", ExploitPanel, 16, 1)
        AddCrasher("LP VELOCITY", "⚡", "Crash the server using a LuckPerms exploit", "", "exploit,lpv", ExploitPanel, 17, 1)
        AddCrasher("REPORT CRASHER", "⚔️", "Crash the server using a /report exploit", "", "exploit,reportcrasher", ExploitPanel, 18, 1)
        AddCrasher("SWING CRASHER", "⚔️", "Crash the server using a packet exploit", "", "exploit,swingcrasher", ExploitPanel, 19, 1)
        AddCrasher("CLICK CRASHER", "⛏️", "Crash the server using a packet exploit", "", "exploit,clickcrasher", ExploitPanel, 20, 1)
        AddCrasher("CLICK CRASHER #2", "⛏️", "Crash the server using a packet exploit", "", "exploit,click2crasher", ExploitPanel, 21, 1)
        AddCrasher("CLICK CRASHER #3", "⛏️", "Crash the server using a packet exploit", "", "exploit,click3crasher", ExploitPanel, 22, 1)
        AddCrasher("SKULL CRASHER", "🔥", "Crash the server using invalid heads", "", "exploit,skullcrasher", ExploitPanel, 23, 1)
        AddCrasher("SIGN CRASHER", "🪧", "Crash the server using invalid signs", "", "exploit,signcrasher", ExploitPanel, 24, 1)
        AddCrasher("REGISTER FLOOD", "⛏️", "Crash the server using a packet exploit", "", "exploit,registerflood", ExploitPanel, 25, 1)
        AddCrasher("NBT-AMPLIFICATION", "🔥", "Crash the server using a packet exploit", "", "exploit,nbtamplification", ExploitPanel, 26, 1)
        AddCrasher("ANVIL CRASHBLOCK", "⛏️", "Give you a crash block in your shoe slot (works only in creative)", "", "exploit,anvilcrasher", ExploitPanel, 27, 1)
        AddCrasher("MVC CONSOLE-SPAM", "⚔️", "Spam the console with a Multiverse-core exploit", "", "exploit,consolespam", ExploitPanel, 28, 1)
        AddCrasher("ITEM CRASHER", "🔥", "Crash the server by flooding item interaction", "", "exploit,itemcrasher", ExploitPanel, 29, 1)
        AddCrasher("ITEM CRASHER #2", "🔥", "Crash the server by flooding item interaction", "", "exploit,item2crasher", ExploitPanel, 30, 1)
        AddCrasher("ITEM CRASHER #3", "🔥", "Crash the server by flooding item interaction", "", "exploit,item3crasher", ExploitPanel, 31, 1)
        AddCrasher("YAW CRASHER", "🔥", "Crash the server using a packet exploit", "", "exploit,yawcrasher", ExploitPanel, 32, 1)
        AddCrasher("CHEST CRASHER", "⛏️", "Give you a chest that crash the server (only works in creative)" & vbCrLf & "BYTES IN CHEST:", "6000", "crash,floppa2 1", ExploitPanel, 33, 0)
        AddCrasher("LIMBOAUTH CRASHER", "⚔️", "Crash the server using a LimboAuth exploit", "", "exploit,limboauth", ExploitPanel, 34, 1)

        'KICK
        AddCrasher("KICK A PLAYER", "🚀", "Kick a player from the server", "Player", "exploit,kickplayer", KickPanel, 0, 0)
        AddCrasher("KICK ALL", "🚀", "Kick all players from the server", "", "exploit,kickall", KickPanel, 1, 1)
        AddCrasher("KICK ALL #2", "🚀", "Kick all players from the server", "", "kickbypass", KickPanel, 2, 1)

        'CHEATS DE MOUVEMENT
        AddCrasher("FLY", "🚀", "Allow you to fly", "", "cheat,fly", MovementPanel, 0, 4)
        AddCrasher("GLIDE", "🪶", "Allow you to glide", "", "cheat,glide", MovementPanel, 1, 4)
        AddCrasher("SPEED", "🪶", "Boost your speed", "", "cheat,speed", MovementPanel, 2, 4)
        AddCrasher("SPIDER", "🕷️", "Allow you to climb walls", "", "cheat,spider", MovementPanel, 3, 4)
        AddCrasher("SPRINT", "⚡", "Allow you to sprint automatically", "", "cheat,sprint", MovementPanel, 4, 4)
        AddCrasher("WATERWALK", "💦", "Allow you to walk on water", "", "cheat,waterwalk", MovementPanel, 5, 4)

        'CHEATS JOUEUR
        AddCrasher("FASTEAT", "🐂", "Boost your eating speed", "", "cheat,fasteat", PlayerPanel, 0, 4)
        AddCrasher("FASTPLACE", "🧱", "Allow you to place blocks quickly", "", "cheat,fastplace", PlayerPanel, 1, 4)
        AddCrasher("NOFALL", "🚀", "Disable fall damages", "", "cheat,nofall", PlayerPanel, 2, 4)
        AddCrasher("REGEN", "🍎", "Regenerate your hearts", "", "cheat,regen", PlayerPanel, 3, 4)
        AddCrasher("TIMER", "⌚", "Boost your game speed", "", "cheat,timer", PlayerPanel, 4, 4)

        'CHEATS VISUEL
        AddCrasher("FULLBRIGHT", "🔦", "Remove shadows of your game", "", "cheat,fullbright", RenderPanel, 0, 4)

        'OPTIONS
        AddCrasher("FAKE-GM", "⚡", "Change your client-side gamemode", "Créatif", "fakegm,", OptionsPanel, 0, 2)
        AddCrasher("PLUGINS", "🗒️", "Show all plugins of the server", "", "plugins", OptionsPanel, 1, 1)
        AddCrasher("THREADS", "⚙️", "Show threads infos", "", "threads", OptionsPanel, 2, 1)
        AddCrasher("CLEAR CHAT", "🧹", "Clear chat messages", "", "clearchat", OptionsPanel, 3, 1)
        AddCrasher("CHANGE NICKNAME", "💻", "Change your nickname", "Nickname", "changeusername", OptionsPanel, 4, 0)
        AddCrasher("CRASHERS LIST", "⚡", "Display a list of all crashers", "", "bypass", OptionsPanel, 5, 1)

        'BOTS
        AddCrasher("BOTS (1.8 PROTOCOL)", "🤖", "", "", "bot,", BotsPanel, 0, 3)
        AddCrasher("BOTS (VIAVERSION)", "🤖", "", "", "instant,", BotsPanel, 1, 3)
        AddCrasher("AEGIS BYPASS", "🤖", "Simple Aegis bypass", "", "aegis,DARKNESS,1500{CLEARSPACE}", BotsPanel, 2, 1)
        AddCrasher("IP STOPPER", "🔥", "", "", "ipstopper,", BotsPanel, 3, 5)
        AddCrasher("SOCKET FLOOD", "🔥", "Flood the server with sockets", "", "exploit,socketflood", BotsPanel, 4, 1)

        'THEME
        AddCrasher("PURPLE", "🪶", "Change the theme of the client to purple", "", "setcolor,violet", ThemePanel, 0, 1)
        AddCrasher("RED/PINK", "🪶", "Change the theme of the client to red/pink", "", "setcolor,rouge", ThemePanel, 1, 1)
        AddCrasher("BLUE", "🪶", "Change the theme of the client to blue", "", "setcolor,bleu", ThemePanel, 2, 1)
        AddCrasher("GREEN", "🪶", "Change the theme of the client to green", "", "setcolor,vert", ThemePanel, 3, 1)
        AddCrasher("GRAY", "🪶", "Change the theme of the client to gray", "", "setcolor,gris", ThemePanel, 4, 1)
        AddCrasher("ORANGE", "🪶", "Change the theme of the client to orange", "", "setcolor,orange", ThemePanel, 5, 1)

        'CHARGER LE PANEL DES CRASHERS
        ShowPanel(CrasherPanel)

        Dim SW As New IO.StreamWriter("C:\Users\" & Environment.UserName & "\runcmd.txt")
        SW.Write("loggon," & SessionManager.IIlIllIllIlIllIl(Label6.Text, "h3jNkv48").Replace("=", ""))
        SW.Close()
        Dim SW2 As New IO.StreamWriter("C:\Users\" & Environment.UserName & "\runcmd.txt")
        SW2.Write("loggon," & SessionManager.IIlIllIllIlIllIl(Label6.Text, "h3jNkv48").Replace("=", ""))
        SW2.Close()
        Dim SW3 As New IO.StreamWriter("C:\Users\" & Environment.UserName & "\runcmd.txt")
        SW3.Write("loggon," & SessionManager.IIlIllIllIlIllIl(Label6.Text, "h3jNkv48").Replace("=", ""))
        SW3.Close()
    End Sub

    Public Function AddCrasher(name As String, icon As String, description As String, defaultArgs As String, startWith As String, panel As Panel, pos As Integer, style As Integer)
        On Error Resume Next

        NbrItem += 1
        Label6.Text = "Darkness Client" & vbCrLf & "Version 1.3"

        Dim crashItem1 As New CrashItem
        crashItem1.TopLevel = False

        panel.Controls.Add(crashItem1)
        crashItem1.Show()
        crashItem1.BringToFront()

        If pos < 3 Then
            crashItem1.Location = New Point(28 + (pos * (268 - 32)), (Math.Truncate(pos / 3) * (147 + 12)))
        ElseIf pos > 2 And pos < 6 Then
            crashItem1.Location = New Point(28 + ((pos - 3) * (268 - 32)), (Math.Truncate(pos / 3) * (147 + 12)))
        ElseIf pos > 5 And pos < 9 Then
            crashItem1.Location = New Point(28 + ((pos - 6) * (268 - 32)), (Math.Truncate(pos / 3) * (147 + 12)))
        ElseIf pos > 8 And pos < 12 Then
            crashItem1.Location = New Point(28 + ((pos - 9) * (268 - 32)), (Math.Truncate(pos / 3) * (147 + 12)))
        ElseIf pos > 11 And pos < 15 Then
            crashItem1.Location = New Point(28 + ((pos - 12) * (268 - 32)), (Math.Truncate(pos / 3) * (147 + 12)))
        ElseIf pos > 14 And pos < 18 Then
            crashItem1.Location = New Point(28 + ((pos - 15) * (268 - 32)), (Math.Truncate(pos / 3) * (147 + 12)))
        ElseIf pos > 17 And pos < 21 Then
            crashItem1.Location = New Point(28 + ((pos - 18) * (268 - 32)), (Math.Truncate(pos / 3) * (147 + 12)))
        ElseIf pos > 20 And pos < 24 Then
            crashItem1.Location = New Point(28 + ((pos - 21) * (268 - 32)), (Math.Truncate(pos / 3) * (147 + 12)))
        ElseIf pos > 23 And pos < 27 Then
            crashItem1.Location = New Point(28 + ((pos - 24) * (268 - 32)), (Math.Truncate(pos / 3) * (147 + 12)))
        ElseIf pos > 26 And pos < 30 Then
            crashItem1.Location = New Point(28 + ((pos - 27) * (268 - 32)), (Math.Truncate(pos / 3) * (147 + 12)))
        ElseIf pos > 29 And pos < 33 Then
            crashItem1.Location = New Point(28 + ((pos - 30) * (268 - 32)), (Math.Truncate(pos / 3) * (147 + 12)))
        ElseIf pos > 32 And pos < 36 Then
            crashItem1.Location = New Point(28 + ((pos - 33) * (268 - 32)), (Math.Truncate(pos / 3) * (147 + 12)))
        ElseIf pos > 35 And pos < 39 Then
            crashItem1.Location = New Point(28 + ((pos - 36) * (268 - 32)), (Math.Truncate(pos / 3) * (147 + 12)))
        ElseIf pos > 38 And pos < 42 Then
            crashItem1.Location = New Point(28 + ((pos - 39) * (268 - 32)), (Math.Truncate(pos / 3) * (147 + 12)))
        ElseIf pos > 41 And pos < 45 Then
            crashItem1.Location = New Point(28 + ((pos - 42) * (268 - 32)), (Math.Truncate(pos / 3) * (147 + 12)))
        ElseIf pos > 44 And pos < 48 Then
            crashItem1.Location = New Point(28 + ((pos - 45) * (268 - 32)), (Math.Truncate(pos / 3) * (147 + 12)))
        ElseIf pos > 47 And pos < 51 Then
            crashItem1.Location = New Point(28 + ((pos - 48) * (268 - 32)), (Math.Truncate(pos / 3) * (147 + 12)))
        ElseIf pos > 50 And pos < 54 Then
            crashItem1.Location = New Point(28 + ((pos - 51) * (268 - 32)), (Math.Truncate(pos / 3) * (147 + 12)))
        End If

        crashItem1.CrasherName.Text = icon & " | " & name.ToUpper
        crashItem1.crashCommand = startWith & " " & defaultArgs
        crashItem1.CrasherDescription.Text = description
        crashItem1.start = startWith
        crashItem1.oldArgs = defaultArgs
        crashItem1.TextBox1.Text = defaultArgs


        If style = 1 Then
            crashItem1.TextBox1.Hide()
        End If

        If style = 2 Then
            crashItem1.ComboBox1.Show()
        End If

        If style = 3 Then
            crashItem1.TextBox1.Hide()
            crashItem1.Label1.Show()
            crashItem1.Label2.Show()
            crashItem1.TextBox2.Show()
            crashItem1.TextBox3.Show()
            crashItem1.crashCommand = (crashItem1.start & crashItem1.TextBox3.Text & "," & crashItem1.TextBox2.Text).Replace("  ", "")
        End If

        If style = 4 Then
            crashItem1.TextBox1.Hide()
            crashItem1.cheatMode = True
        End If

        If style = 5 Then

            crashItem1.var1 = False
            crashItem1.Label1.Text = "IP:"
            crashItem1.Label2.Text = "Port:"
            crashItem1.TextBox2.Text = "127.0.0.1"
            crashItem1.TextBox2.MaxLength = 80
            crashItem1.TextBox3.Text = "25565"
            crashItem1.TextBox1.Hide()
            crashItem1.Label1.Show()
            crashItem1.Label2.Show()
            crashItem1.TextBox2.Show()
            crashItem1.TextBox3.Show()
            crashItem1.crashCommand = (crashItem1.start & crashItem1.TextBox3.Text & "," & crashItem1.TextBox2.Text).Replace("  ", "")
        End If
    End Function

    Private Sub Form1_MouseDown(sender As Object, e As MouseEventArgs) Handles Me.MouseDown, PictureBox1.MouseDown, Panel1.MouseDown, PictureBox2.MouseDown, CrasherPanel.MouseDown, ExploitPanel.MouseDown, KickPanel.MouseDown, MovementPanel.MouseDown, PlayerPanel.MouseDown, RenderPanel.MouseDown, OptionsPanel.MouseDown, BotsPanel.MouseDown, Label6.MouseDown
        On Error Resume Next
        x = Control.MousePosition.X - Location.X
        y = Control.MousePosition.Y - Location.Y
    End Sub

    Private Sub Form1_MouseMove(sender As Object, e As MouseEventArgs) Handles Me.MouseMove, PictureBox1.MouseMove, Panel1.MouseMove, PictureBox2.MouseMove, CrasherPanel.MouseMove, ExploitPanel.MouseMove, KickPanel.MouseMove, MovementPanel.MouseMove, PlayerPanel.MouseMove, RenderPanel.MouseMove, OptionsPanel.MouseMove, BotsPanel.MouseMove, Label6.MouseMove
        On Error Resume Next
        If e.Button = Windows.Forms.MouseButtons.Left Then
            newPoint = Control.MousePosition
            newPoint.X -= x
            newPoint.Y -= y
            Location = newPoint
        End If
    End Sub

    Private Sub CrashersButton_Click(sender As Object, e As EventArgs) Handles CrashersButton.Click
        On Error Resume Next
        ShowPanel(CrasherPanel)
    End Sub

    Public Function ShowPanel(panel As Panel)
        On Error Resume Next
        CrasherPanel.Hide()
        ExploitPanel.Hide()
        KickPanel.Hide()
        MovementPanel.Hide()
        PlayerPanel.Hide()
        RenderPanel.Hide()
        OptionsPanel.Hide()
        BotsPanel.Hide()
        ThemePanel.Hide()
        CustomPanel.Hide()

        panel.Show()
    End Function

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        On Error Resume Next
        ShowPanel(ExploitPanel)
    End Sub

    Private Sub Button8_Click(sender As Object, e As EventArgs) Handles Button8.Click
        On Error Resume Next
        ShowPanel(KickPanel)
    End Sub

    Private Sub Button5_Click(sender As Object, e As EventArgs) Handles Button5.Click
        On Error Resume Next
        ShowPanel(MovementPanel)
    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        On Error Resume Next
        ShowPanel(PlayerPanel)
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        On Error Resume Next
        ShowPanel(RenderPanel)
    End Sub

    Private Sub Button6_Click(sender As Object, e As EventArgs) Handles Button6.Click
        On Error Resume Next
        ShowPanel(OptionsPanel)
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        On Error Resume Next
        ShowPanel(BotsPanel)
    End Sub

    Public Function UpdateTheme()
        On Error Resume Next
        CrashersButton.ForeColor = themeColor
        Button1.ForeColor = themeColor
        Button2.ForeColor = themeColor
        Button3.ForeColor = themeColor
        Button4.ForeColor = themeColor
        Button5.ForeColor = themeColor
        Button6.ForeColor = themeColor
        Button7.ForeColor = themeColor
        Button8.ForeColor = themeColor
        Button9.ForeColor = themeColor
        Button10.ForeColor = themeColor
        Custom1.BackColor = themeColor
        Custom2.BackColor = themeColor
        Custom3.BackColor = themeColor
        Custom4.BackColor = themeColor
        Custom5.BackColor = themeColor
        Custom6.BackColor = themeColor

    End Function

    Private Sub Button9_Click(sender As Object, e As EventArgs) Handles Button9.Click
        On Error Resume Next
        ShowPanel(ThemePanel)
    End Sub

    Private Sub Button7_Click(sender As Object, e As EventArgs) Handles Button7.Click
        On Error Resume Next
        MsgBox(" " & vbCrLf & "DESCRIPTION:" & vbCrLf & "Darkness Client is a Minecraft client with many exploits, crashers and cheats." & vbCrLf & vbCrLf & "CUSTOMIZATION:" & vbCrLf & "You can easily change the UI with the ""Theme"" menu." & vbCrLf & vbCrLf & "DARKNESS TEAM:" & vbCrLf & "CubexFR » CEO & Developer" & vbCrLf & "Netsu » CEO & Developer" & vbCrLf & "Pyko » Media & Developer" & vbCrLf & vbCrLf & "CREDITS:" & vbCrLf & "Special thanks to the following people for their contributions:" & vbCrLf & vbCrLf & "Delyfss » He coded some exploits (discord: delyfss)" & vbCrLf & "Sn0wy » He helped to code a bypass for LPX (latest)" & vbCrLf & "Pyko » He helped to code a bypass for LPX (latest)" & vbCrLf & "Linux » He helped for obfuscation", MsgBoxStyle.Information, "Darkness Client")
    End Sub

    Private Sub Button10_Click(sender As Object, e As EventArgs) Handles Button10.Click
        On Error Resume Next
        ShowPanel(CustomPanel)
    End Sub

    Private Sub Label9_Click(sender As Object, e As EventArgs) Handles Label9.Click, Label8.Click
        On Error Resume Next
        If Label9.Text = "WindowClick" Then
            Label9.Text = "BlockPlace"
        ElseIf Label9.Text = "BlockPlace" Then
            Label9.Text = "Creative (Drop)"
        Else
            Label9.Text = "WindowClick"
        End If
    End Sub

    Private Sub Button51_Click(sender As Object, e As EventArgs) Handles Button51.Click
        On Error Resume Next
        sendClientInput("custom," & Label67.Text.ToLower.Replace("-", ""))
    End Sub

    Public Function sendClientInput(input As String)
        On Error Resume Next
        Dim SW As New IO.StreamWriter("C:\Users\" & Environment.UserName & "\runcmd.txt")
        SW.Write(input)
        SW.Close()
    End Function

    Private Sub Label67_Click(sender As Object, e As EventArgs) Handles Label67.Click, Label68.Click
        On Error Resume Next
        If Label67.Text = "LPB-Hard" Then
            Label67.Text = "LPV-Hard"
        ElseIf Label67.Text = "LPV-Hard" Then
            Label67.Text = "LPB-Small"
        ElseIf Label67.Text = "LPB-Small" Then
            Label67.Text = "LPV-Small"
        ElseIf Label67.Text = "LPV-Small" Then
            Label67.Text = "LPB-Hard"
        End If

    End Sub

    Private Sub Label54_Click(sender As Object, e As EventArgs) Handles Label54.Click, Label55.Click
        On Error Resume Next
        If Label54.Text = "OldJartex" Then
            Label54.Text = "MassChunkLoad"
        ElseIf Label54.Text = "MassChunkLoad" Then
            Label54.Text = "SpigotGuard"
        ElseIf Label54.Text = "SpigotGuard" Then
            Label54.Text = "OldPikaAbuse"
        ElseIf Label54.Text = "OldPikaAbuse" Then
            Label54.Text = "NCP"
        ElseIf Label54.Text = "NCP" Then
            Label54.Text = "AAC5"
        ElseIf Label54.Text = "AAC5" Then
            Label54.Text = "OldJartex"
        End If
    End Sub

    Private Sub Button43_Click(sender As Object, e As EventArgs) Handles Button43.Click
        On Error Resume Next
        If Label54.Text = "OldJartex" Then
            sendClientInput("crash,jupiter1 1 9 200 10000 1 0")
        ElseIf Label54.Text = "MassChunkLoad" Then
            sendClientInput("crash,zebra1 1")
        ElseIf Label54.Text = "SpigotGuard" Then
            sendClientInput("crash,zebra1 1")
        ElseIf Label54.Text = "OldPikaAbuse" Then
            sendClientInput("exploit,aaccrasher")
        ElseIf Label54.Text = "NCP" Then
            sendClientInput("crash,yoshi4 5")
        ElseIf Label54.Text = "AAC5" Then
            sendClientInput("crash,marki3 5")
        End If

    End Sub

    Private Sub Label64_Click(sender As Object, e As EventArgs) Handles Label64.Click, Label65.Click
        On Error Resume Next
        If Label64.Text = "Creative (Drop)" Then
            Label64.Text = "Creative (Give)"
        ElseIf Label64.Text = "Creative (Give)" Then
            Label64.Text = "WindowClick"
        ElseIf Label64.Text = "WindowClick" Then
            Label64.Text = "BlockPlace"
        ElseIf Label64.Text = "BlockPlace" Then
            Label64.Text = "Creative (Drop)"
        End If
    End Sub

    Private Sub Button42_Click(sender As Object, e As EventArgs) Handles Button42.Click
        On Error Resume Next
        If Label62.Text = "0" Then
            Label62.Text = "1"
        ElseIf Label62.Text = "1" Then
            Label62.Text = "5"
        Else
            Label62.Text = (Label62.Text + 5)
        End If
    End Sub

    Private Sub Button41_Click(sender As Object, e As EventArgs) Handles Button41.Click
        On Error Resume Next
        If Label62.Text = "5" Then
            Label62.Text = "1"
        ElseIf Label62.Text = "1" Then
            Label62.Text = "0"
        Else
            Label62.Text = (Label62.Text - 5)
        End If

        If Label62.Text.Contains("-") Then
            Label62.Text = "0"
        End If
    End Sub

    Private Sub Button40_Click(sender As Object, e As EventArgs) Handles Button40.Click
        On Error Resume Next
        Label60.Text = Label60.Text.Replace("ms", "")
        If Label60.Text = "0" Then
            Label60.Text = "1"
        ElseIf Label60.Text = "1" Then
            Label60.Text = "5"
        Else
            Label60.Text = (Label60.Text + 5)
        End If
        Label60.Text = Label60.Text & "ms"
    End Sub

    Private Sub Button39_Click(sender As Object, e As EventArgs) Handles Button39.Click
        On Error Resume Next
        Label60.Text = Label60.Text.Replace("ms", "")
        If Label60.Text = "5" Then
            Label60.Text = "1"
        ElseIf Label60.Text = "1" Then
            Label60.Text = "0"
        Else
            Label60.Text = (Label60.Text - 5)
        End If

        If Label60.Text.Contains("-") Then
            Label60.Text = "0"
        End If
        Label60.Text = Label60.Text & "ms"
    End Sub

    Private Sub Button45_Click(sender As Object, e As EventArgs) Handles Button45.Click
        On Error Resume Next
        sendClientInput("custom,netty" & Label64.Text.ToLower.Replace(" ", "").Replace("(", "").Replace(")", "") & " " & Label62.Text & " " & Label60.Text.Replace("ms", ""))
    End Sub

    Private Sub Label40_Click(sender As Object, e As EventArgs) Handles Label40.Click, Label41.Click
        On Error Resume Next
        If Label40.Text = "DoubleSolve" Then
            Label40.Text = "ClassicCalc"
        ElseIf Label40.Text = "ClassicCalc" Then
            Label40.Text = "WESolveBypass"
        ElseIf Label40.Text = "WESolveBypass" Then
            Label40.Text = "ClassicEval"
        ElseIf Label40.Text = "ClassicEval" Then
            Label40.Text = "Ultimate"
        ElseIf Label40.Text = "Ultimate" Then
            Label40.Text = "DoubleSolve"
        End If
    End Sub

    Private Sub Button30_Click(sender As Object, e As EventArgs) Handles Button30.Click
        On Error Resume Next
        If Label38.Text = "0" Then
            Label38.Text = "1"
        ElseIf Label38.Text = "1" Then
            Label38.Text = "5"
        Else
            Label38.Text = (Label38.Text + 5)
        End If
    End Sub

    Private Sub Button29_Click(sender As Object, e As EventArgs) Handles Button29.Click
        On Error Resume Next
        If Label38.Text = "5" Then
            Label38.Text = "1"
        ElseIf Label38.Text = "1" Then
            Label38.Text = "0"
        Else
            Label38.Text = (Label38.Text - 5)
        End If

        If Label38.Text.Contains("-") Then
            Label38.Text = "0"
        End If
    End Sub

    Private Sub Button48_Click(sender As Object, e As EventArgs) Handles Button48.Click
        On Error Resume Next
        sendClientInput("custom,crwe" & Label40.Text.ToLower.Replace(" ", "").Replace("(", "").Replace(")", "") & " " & Label38.Text & " " & Label33.Text.Replace("ms", ""))
    End Sub

    Private Sub Label35_Click(sender As Object, e As EventArgs) Handles Label35.Click, Label36.Click
        On Error Resume Next
        If Label35.Text = "TarUltimate" Then
            Label35.Text = "ClassicTo"
        ElseIf Label35.Text = "ClassicTo" Then
            Label35.Text = "SpigotGuard"
        ElseIf Label35.Text = "SpigotGuard" Then
            Label35.Text = "TarUltimate"
        End If
    End Sub

    Private Sub Button26_Click(sender As Object, e As EventArgs) Handles Button26.Click
        On Error Resume Next
        If Label26.Text = "0" Then
            Label26.Text = "1"
        ElseIf Label26.Text = "1" Then
            Label26.Text = "5"
        Else
            Label26.Text = (Label26.Text + 5)
        End If
    End Sub

    Private Sub Button25_Click(sender As Object, e As EventArgs) Handles Button25.Click
        On Error Resume Next
        If Label26.Text = "5" Then
            Label26.Text = "1"
        ElseIf Label26.Text = "1" Then
            Label26.Text = "0"
        Else
            Label26.Text = (Label26.Text - 5)
        End If

        If Label26.Text.Contains("-") Then
            Label26.Text = "0"
        End If
    End Sub

    Private Sub Button28_Click(sender As Object, e As EventArgs) Handles Button28.Click
        On Error Resume Next
        Label33.Text = Label33.Text.Replace("ms", "")
        If Label33.Text = "0" Then
            Label33.Text = "1"
        ElseIf Label33.Text = "1" Then
            Label33.Text = "5"
        Else
            Label33.Text = (Label33.Text + 5)
        End If
        Label33.Text = Label33.Text & "ms"
    End Sub

    Private Sub Button27_Click(sender As Object, e As EventArgs) Handles Button27.Click
        On Error Resume Next
        Label33.Text = Label33.Text.Replace("ms", "")
        If Label33.Text = "5" Then
            Label33.Text = "1"
        ElseIf Label33.Text = "1" Then
            Label33.Text = "0"
        Else
            Label33.Text = (Label33.Text - 5)
        End If

        If Label33.Text.Contains("-") Then
            Label33.Text = "0"
        End If
        Label33.Text = Label33.Text & "ms"
    End Sub

    Private Sub Button24_Click(sender As Object, e As EventArgs) Handles Button24.Click
        On Error Resume Next
        Label24.Text = Label24.Text.Replace("ms", "")
        If Label24.Text = "0" Then
            Label24.Text = "1"
        ElseIf Label24.Text = "1" Then
            Label24.Text = "5"
        Else
            Label24.Text = (Label24.Text + 5)
        End If
        Label24.Text = Label24.Text & "ms"
    End Sub

    Private Sub Button23_Click(sender As Object, e As EventArgs) Handles Button23.Click
        On Error Resume Next
        Label24.Text = Label24.Text.Replace("ms", "")
        If Label24.Text = "5" Then
            Label24.Text = "1"
        ElseIf Label24.Text = "1" Then
            Label24.Text = "0"
        Else
            Label24.Text = (Label24.Text - 5)
        End If

        If Label24.Text.Contains("-") Then
            Label24.Text = "0"
        End If
        Label24.Text = Label24.Text & "ms"
    End Sub

    Private Sub Button47_Click(sender As Object, e As EventArgs) Handles Button47.Click
        On Error Resume Next
        sendClientInput("custom,fawe" & Label35.Text.ToLower.Replace(" ", "").Replace("(", "").Replace(")", "") & " " & Label26.Text & " " & Label24.Text.Replace("ms", ""))
    End Sub

    Private Sub Label47_Click(sender As Object, e As EventArgs) Handles Label47.Click
        On Error Resume Next
        If Label47.Text = "MVC-FIX" Then
            Label47.Text = "LPX"
        ElseIf Label47.Text = "LPX" Then
            Label47.Text = "ClassicMVC"
        ElseIf Label47.Text = "ClassicMVC" Then
            Label47.Text = "MVC-FIX"
        End If
    End Sub

    Private Sub Button34_Click(sender As Object, e As EventArgs) Handles Button34.Click
        On Error Resume Next
        If Label45.Text = "0" Then
            Label45.Text = "1"
        ElseIf Label45.Text = "1" Then
            Label45.Text = "5"
        Else
            Label45.Text = (Label45.Text + 5)
        End If
    End Sub

    Private Sub Button33_Click(sender As Object, e As EventArgs) Handles Button33.Click
        On Error Resume Next
        If Label45.Text = "5" Then
            Label45.Text = "1"
        ElseIf Label45.Text = "1" Then
            Label45.Text = "0"
        Else
            Label45.Text = (Label45.Text - 5)
        End If

        If Label45.Text.Contains("-") Then
            Label45.Text = "0"
        End If
    End Sub

    Private Sub Button32_Click(sender As Object, e As EventArgs) Handles Button32.Click
        On Error Resume Next
        Label43.Text = Label43.Text.Replace("ms", "")
        If Label43.Text = "0" Then
            Label43.Text = "1"
        ElseIf Label43.Text = "1" Then
            Label43.Text = "5"
        Else
            Label43.Text = (Label43.Text + 5)
        End If
        Label43.Text = Label43.Text & "ms"
    End Sub

    Private Sub Button31_Click(sender As Object, e As EventArgs) Handles Button31.Click
        On Error Resume Next
        Label43.Text = Label43.Text.Replace("ms", "")
        If Label43.Text = "5" Then
            Label43.Text = "1"
        ElseIf Label43.Text = "1" Then
            Label43.Text = "0"
        Else
            Label43.Text = (Label43.Text - 5)
        End If

        If Label43.Text.Contains("-") Then
            Label43.Text = "0"
        End If
        Label43.Text = Label43.Text & "ms"
    End Sub

    Private Sub Button49_Click(sender As Object, e As EventArgs) Handles Button49.Click
        On Error Resume Next
        sendClientInput("custom,mvc" & Label47.Text.ToLower.Replace(" ", "").Replace("(", "").Replace(")", "").Replace("-", "") & " " & Label45.Text & " " & Label43.Text.Replace("ms", ""))
    End Sub

    Private Sub Label57_Click(sender As Object, e As EventArgs) Handles Label57.Click, Label58.Click
        On Error Resume Next
        If Label57.Text = "ExploitFixer" Then
            Label57.Text = "SpigotGuard"
        ElseIf Label57.Text = "SpigotGuard" Then
            Label57.Text = "LPX"
        ElseIf Label57.Text = "LPX" Then
            Label57.Text = "ExploitFixer"
        End If
    End Sub

    Private Sub Button38_Click(sender As Object, e As EventArgs) Handles Button38.Click
        On Error Resume Next
        If Label52.Text = "0" Then
            Label52.Text = "1"
        ElseIf Label52.Text = "1" Then
            Label52.Text = "5"
        Else
            Label52.Text = (Label52.Text + 5)
        End If
    End Sub

    Private Sub Button37_Click(sender As Object, e As EventArgs) Handles Button37.Click
        On Error Resume Next
        If Label52.Text = "5" Then
            Label52.Text = "1"
        ElseIf Label52.Text = "1" Then
            Label52.Text = "0"
        Else
            Label52.Text = (Label52.Text - 5)
        End If

        If Label52.Text.Contains("-") Then
            Label52.Text = "0"
        End If
    End Sub

    Private Sub Button36_Click(sender As Object, e As EventArgs) Handles Button36.Click
        On Error Resume Next
        Label50.Text = Label50.Text.Replace("ms", "")
        If Label50.Text = "0" Then
            Label50.Text = "1"
        ElseIf Label50.Text = "1" Then
            Label50.Text = "5"
        Else
            Label50.Text = (Label50.Text + 5)
        End If
        Label50.Text = Label50.Text & "ms"
    End Sub

    Private Sub Button35_Click(sender As Object, e As EventArgs) Handles Button35.Click
        On Error Resume Next
        Label50.Text = Label50.Text.Replace("ms", "")
        If Label50.Text = "5" Then
            Label50.Text = "1"
        ElseIf Label50.Text = "1" Then
            Label50.Text = "0"
        Else
            Label50.Text = (Label50.Text - 5)
        End If

        If Label50.Text.Contains("-") Then
            Label50.Text = "0"
        End If
        Label50.Text = Label50.Text & "ms"
    End Sub

    Private Sub Button46_Click(sender As Object, e As EventArgs) Handles Button46.Click
        On Error Resume Next
        sendClientInput("custom,netty" & Label57.Text.ToLower.Replace(" ", "").Replace("(", "").Replace(")", "").Replace("-", "") & " " & Label52.Text & " " & Label50.Text.Replace("ms", ""))
    End Sub

    Private Sub Label28_Click(sender As Object, e As EventArgs) Handles Label28.Click, Label29.Click
        On Error Resume Next
        If Label28.Text = "Zero-IP" Then
            Label28.Text = "Small-IP"
        ElseIf Label28.Text = "Small-IP" Then
            Label28.Text = "Zero-Hostname"
        ElseIf Label28.Text = "Zero-Hostname" Then
            Label28.Text = "Zero-IP"
        End If
    End Sub

    Private Sub Button22_Click(sender As Object, e As EventArgs) Handles Button22.Click
        On Error Resume Next
        If Label22.Text = "0" Then
            Label22.Text = "1"
        ElseIf Label22.Text = "1" Then
            Label22.Text = "5"
        Else
            Label22.Text = (Label22.Text + 5)
        End If
    End Sub

    Private Sub Button21_Click(sender As Object, e As EventArgs) Handles Button21.Click
        On Error Resume Next
        If Label22.Text = "5" Then
            Label22.Text = "1"
        ElseIf Label22.Text = "1" Then
            Label22.Text = "0"
        Else
            Label22.Text = (Label22.Text - 5)
        End If

        If Label22.Text.Contains("-") Then
            Label22.Text = "0"
        End If
    End Sub

    Private Sub Button20_Click(sender As Object, e As EventArgs) Handles Button20.Click
        On Error Resume Next
        Label20.Text = Label20.Text.Replace("ms", "")
        If Label20.Text = "0" Then
            Label20.Text = "1"
        ElseIf Label20.Text = "1" Then
            Label20.Text = "5"
        Else
            Label20.Text = (Label20.Text + 5)
        End If
        Label20.Text = Label20.Text & "ms"
    End Sub

    Private Sub Button19_Click(sender As Object, e As EventArgs) Handles Button19.Click
        On Error Resume Next
        Label20.Text = Label20.Text.Replace("ms", "")
        If Label20.Text = "5" Then
            Label20.Text = "1"
        ElseIf Label20.Text = "1" Then
            Label20.Text = "0"
        Else
            Label20.Text = (Label20.Text - 5)
        End If

        If Label20.Text.Contains("-") Then
            Label20.Text = "0"
        End If
        Label20.Text = Label20.Text & "ms"
    End Sub

    Private Sub Button50_Click(sender As Object, e As EventArgs) Handles Button50.Click
        On Error Resume Next
        sendClientInput("custom,log" & Label28.Text.ToLower.Replace(" ", "").Replace("(", "").Replace(")", "").Replace("-", "") & " " & Label22.Text & " " & Label20.Text.Replace("ms", ""))
    End Sub

    Private Sub Label10_Click(sender As Object, e As EventArgs) Handles Label10.Click, Label11.Click
        On Error Resume Next
        If Label10.Text = "Extra (A)" Then
            Label10.Text = "Points"
        ElseIf Label10.Text = "Points" Then
            Label10.Text = "Random (Alphabetic)"
        Else
            Label10.Text = "Extra (A)"
        End If
    End Sub

    Private Sub Button11_Click(sender As Object, e As EventArgs) Handles Button11.Click
        On Error Resume Next
        If Label12.Text = "0" Then
            Label12.Text = "1"
        ElseIf Label12.Text = "1" Then
            Label12.Text = "5"
        Else
            Label12.Text = (Label12.Text + 5)
        End If
    End Sub

    Private Sub Button12_Click(sender As Object, e As EventArgs) Handles Button12.Click
        On Error Resume Next
        If Label12.Text = "5" Then
            Label12.Text = "1"
        ElseIf Label12.Text = "1" Then
            Label12.Text = "0"
        Else
            Label12.Text = (Label12.Text - 5)
        End If

        If Label12.Text.Contains("-") Then
            Label12.Text = "0"
        End If
    End Sub

    Private Sub Button14_Click(sender As Object, e As EventArgs) Handles Button14.Click
        On Error Resume Next
        If Label14.Text = "0" Then
            Label14.Text = "1"
        ElseIf Label14.Text = "1" Then
            Label14.Text = "5"
        Else
            Label14.Text = (Label14.Text + 5)
        End If
    End Sub

    Private Sub Button13_Click(sender As Object, e As EventArgs) Handles Button13.Click
        On Error Resume Next
        If Label14.Text = "5" Then
            Label14.Text = "1"
        ElseIf Label14.Text = "1" Then
            Label14.Text = "0"
        Else
            Label14.Text = (Label14.Text - 5)
        End If

        If Label14.Text.Contains("-") Then
            Label14.Text = "0"
        End If
    End Sub

    Private Sub Button16_Click(sender As Object, e As EventArgs) Handles Button16.Click
        On Error Resume Next
        If Label16.Text = "0" Then
            Label16.Text = "1"
        ElseIf Label16.Text = "1" Then
            Label16.Text = "5"
        Else
            Label16.Text = (Label16.Text + 5)
        End If
    End Sub

    Private Sub Button15_Click(sender As Object, e As EventArgs) Handles Button15.Click
        On Error Resume Next
        If Label16.Text = "5" Then
            Label16.Text = "1"
        ElseIf Label16.Text = "1" Then
            Label16.Text = "0"
        Else
            Label16.Text = (Label16.Text - 5)
        End If

        If Label16.Text.Contains("-") Then
            Label16.Text = "0"
        End If
    End Sub

    Private Sub Button18_Click(sender As Object, e As EventArgs) Handles Button18.Click
        On Error Resume Next
        Label18.Text = Label18.Text.Replace("ms", "")
        If Label18.Text = "0" Then
            Label18.Text = "1"
        ElseIf Label18.Text = "1" Then
            Label18.Text = "5"
        Else
            Label18.Text = (Label18.Text + 5)
        End If
        Label18.Text = Label18.Text & "ms"
    End Sub

    Private Sub Button17_Click(sender As Object, e As EventArgs) Handles Button17.Click
        On Error Resume Next
        Label18.Text = Label18.Text.Replace("ms", "")
        If Label18.Text = "5" Then
            Label18.Text = "1"
        ElseIf Label18.Text = "1" Then
            Label18.Text = "0"
        Else
            Label18.Text = (Label18.Text - 5)
        End If

        If Label18.Text.Contains("-") Then
            Label18.Text = "0"
        End If
        Label18.Text = Label18.Text & "ms"
    End Sub

    Private Sub Button44_Click(sender As Object, e As EventArgs) Handles Button44.Click
        On Error Resume Next
        Dim prefix As String = ""

        If Label9.Text.Contains("WindowClick") Then
            prefix += "wndclick"
        End If

        If Label10.Text.Contains("BlockPlace") Then
            prefix += "blockplace"
        End If

        If Label10.Text.Contains("Creative (Drop)") Then
            prefix += "creativedrop"
        End If

        If Label10.Text.Contains("Extra (A)") Then
            prefix += "extra"
        End If

        If Label10.Text.Contains("Points") Then
            prefix += "dots"
        End If

        If Label10.Text.Contains("Random (Alphabetic)") Then
            prefix += "rndalphabet"
        End If

        sendClientInput("custom," + prefix + " " & Label12.Text.Replace("ms", "") & " " & Label14.Text.Replace("ms", "") & " " & Label16.Text.Replace("ms", "") & " " & Label18.Text.Replace("ms", ""))
    End Sub
End Class
