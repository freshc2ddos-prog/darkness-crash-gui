﻿Imports System.Net
Imports System.Security.Cryptography
Imports System.Text

Public Class SessionManager

    Public llIIlIllIllIIIlI As String = ""
    Public v As Integer = 0

    Private Sub SessionManager_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Public Function lIIllIlIlIlIlIIIlI()
        On Error Resume Next
        IllIllIIlIlIIllI.Navigate("https://darkness143config.weebly.com/")
        IIlIllIlllIIlIll()
        IlIIllIllIlIllII()
    End Function

    Public Function IIlIIIllIlIlIlIlII()
        On Error Resume Next
        IllIllIIlIlIIllI.Navigate("https://darkness143config.weebly.com/")
        IIlIllIlllIIlIll()
    End Function

    Public Function IIlIllIllIlIllIl(stringToCrypt As String, key As String) As String
        On Error Resume Next
        Dim TB() As Byte = Encoding.UTF8.GetBytes(stringToCrypt)
        Dim KB() As Byte = Encoding.UTF8.GetBytes(key)
        Dim C As New DESCryptoServiceProvider()
        C.Key = KB
        C.IV = KB
        Dim IC As ICryptoTransform = C.CreateEncryptor()
        Dim RB() As Byte = IC.TransformFinalBlock(TB, 0, TB.Length)

        Return Convert.ToBase64String(RB)
    End Function

    Public Function IlIIllIIllIIllIl(stringToCrypt As String, key As String) As String
        On Error Resume Next
        Dim RB() As Byte = Convert.FromBase64String(stringToCrypt)
        Dim KB() As Byte = Encoding.UTF8.GetBytes(key)
        Dim C As New DESCryptoServiceProvider()
        C.Key = KB
        C.IV = KB
        Dim IC As ICryptoTransform = C.CreateDecryptor()
        Dim D() As Byte = IC.TransformFinalBlock(RB, 0, RB.Length)

        Return Encoding.UTF8.GetString(D)
    End Function

    ' Usunięta funkcja weryfikacji PCID
    ' Public Function lIllIIlIlIIllIII(token As String) As Boolean

    Public Function IlIIllIllIlIllII()
        On Error Resume Next
        ' Pomijamy weryfikację PCID i od razu ustawiamy, że sesja jest aktywna
        Form1.lIIllIIlIllIIlIl = True
    End Function

    Private Function IllIIllIIllIIlI(ByVal IllIIllIIllIlI As String) As String
        On Error Resume Next
        Dim IllIIllIIllI As MD5 = MD5.Create()
        Dim lIIlIllIllIl As Byte() = Encoding.ASCII.GetBytes(IllIIllIIllIlI)
        Dim lIIllIIllIlI As Byte() = IllIIllIIllI.ComputeHash(lIIlIllIllIl)
        Dim lIIlIIlIlIlI As New StringBuilder()

        For lIlIIIllIlIl As Integer = 0 To lIIllIIllIlI.Length - 1
            lIIlIIlIlIlI.Append(lIIllIIllIlI(lIlIIIllIlIl).ToString("x2"))
            If Not Math.Truncate(lIlIIIllIlIl / 2) = lIlIIIllIlIl / 2 Then
                lIIlIIlIlIlI.Append("-")
            End If
        Next

        Return (lIIlIIlIlIlI.ToString() & "{PCID}").Replace("-{PCID}", "").Replace("{PCID}", "").ToUpper
    End Function

    Public Function llIIlIIllIlIIIlI(token As String) As String
        On Error Resume Next
        IIlIllIlllIIlIll()
    End Function

    Public Function IIlIllIlllIIlIll() As String
        Exit Function
        Dim url As String = "https://darkness143config.weebly.com/"

        Dim client As New WebClient()
        llIIlIllIllIIIlI = client.DownloadString(url)
        IllIllIIlIlIIllI.Navigate("https://darkness143config.weebly.com/")
    End Function

    Private Sub WebBrowser1_DocumentCompleted(sender As Object, e As WebBrowserDocumentCompletedEventArgs) Handles IllIllIIlIlIIllI.DocumentCompleted
        On Error Resume Next
        Dim results As HtmlElementCollection = IllIllIIlIlIIllI.Document.GetElementsByTagName("div")

        Dim a = 0
        For Each result As HtmlElement In results
            a += 1

            If a = 8 Then
                llIIlIllIllIIIlI = result.InnerText.Replace(vbCrLf, "")
            End If
        Next

        Form1.Opacity = 100
    End Sub

    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        On Error Resume Next
        If Not IllIllIIlIlIIllI.Url.ToString.Contains("darkness143config") Then
            IllIllIIlIlIIllI.Navigate("https://darkness143config.weebly.com/")
        Else
            Timer1.Stop()
        End If
    End Sub

    Private Sub Timer2_Tick(sender As Object, e As EventArgs) Handles Timer2.Tick
        On Error Resume Next
        Timer2.Stop()
        IllIllIIlIlIIllI.Navigate("https://darkness143config.weebly.com/")
    End Sub
End Class
