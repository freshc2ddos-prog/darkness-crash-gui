﻿Public Class CrashItem

    Public crashCommand As String = ""
    Public start As String = ""
    Public oldModeText As String = "Créatif"
    Public oldBotNbr As String = "1500"
    Public oldArgs As String = "100 25 10 15"
    Public cheatMode As Boolean = False
    Public var1 As Boolean = True
    Public old1 As String = "25565"

    Private Sub CrashItem_Click(sender As Object, e As EventArgs) Handles Me.Click, CrasherName.Click, CrasherDescription.Click, Label2.Click, Label1.Click
        On Error Resume Next
        LoadCommand()
    End Sub

    Private Sub CrashItem_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        
    End Sub

    Public Function GetMinecraftProcess() As Process
        Dim processes As Process() = Process.GetProcessesByName("javaw")
        For Each process As Process In processes
            If process.MainWindowTitle.ToLower().Contains("darkness") Then
                Return process
            End If
        Next
        Return Nothing
    End Function

    Public Function LoadCommand()
        On Error Resume Next

        If Not Form1.lIIllIIlIllIIlIl Then
            SessionManager.lIIllIlIlIlIlIIIlI()
            Timer2.Start()
            Exit Function
        End If

        crashCommand = crashCommand.Replace("{CLEARSPACE} ", "").Replace("{CLEARSPACE}", "")
        If BackColor = Color.FromArgb(24, 24, 24) Then
            If crashCommand.Contains("setcolor,violet") Then
                Form1.themeColor = Color.MediumSlateBlue
                Form1.PictureBox1.Image = My.Resources.logo
                Form1.UpdateTheme()
                Dim SW As New IO.StreamWriter(Application.StartupPath & "\theme.txt")
                SW.Write("violet")
                SW.Close()
                Exit Function
            End If

            If crashCommand.Contains("setcolor,rouge") Then
                Form1.themeColor = Color.FromArgb(255, 88, 88)
                Form1.PictureBox1.Image = My.Resources.logored
                Form1.UpdateTheme()
                Dim SW As New IO.StreamWriter(Application.StartupPath & "\theme.txt")
                SW.Write("rouge")
                SW.Close()
                Exit Function
            End If

            If crashCommand.Contains("setcolor,bleu") Then
                Form1.themeColor = Color.DodgerBlue
                Form1.PictureBox1.Image = My.Resources.logoblue
                Form1.UpdateTheme()
                Dim SW As New IO.StreamWriter(Application.StartupPath & "\theme.txt")
                SW.Write("bleu")
                SW.Close()
                Exit Function
            End If

            If crashCommand.Contains("setcolor,vert") Then
                Form1.themeColor = Color.LimeGreen
                Form1.PictureBox1.Image = My.Resources.logogreen
                Form1.UpdateTheme()
                Dim SW As New IO.StreamWriter(Application.StartupPath & "\theme.txt")
                SW.Write("vert")
                SW.Close()
                Exit Function
            End If

            If crashCommand.Contains("setcolor,gris") Then
                Form1.themeColor = Color.DarkGray
                Form1.PictureBox1.Image = My.Resources.logogray
                Form1.UpdateTheme()
                Dim SW As New IO.StreamWriter(Application.StartupPath & "\theme.txt")
                SW.Write("gris")
                SW.Close()
                Exit Function
            End If

            If crashCommand.Contains("setcolor,orange") Then
                Form1.themeColor = Color.Orange
                Form1.PictureBox1.Image = My.Resources.logoorange
                Form1.UpdateTheme()
                Dim SW As New IO.StreamWriter(Application.StartupPath & "\theme.txt")
                SW.Write("orange")
                SW.Close()
                Exit Function
            End If
        End If

        Dim process As Process = GetMinecraftProcess()
        If process Is Nothing Then
            MsgBox("The Minecraft client Darkness isn't launched!", 16, "Error")
            Exit Function
        End If

        If cheatMode = False Then
            If BackColor = Color.FromArgb(24, 24, 24) Then
                Dim SW As New IO.StreamWriter("C:\Users\" & Environment.UserName & "\runcmd.txt")
                SW.Write(crashCommand.Replace("é", "e"))
                SW.Close()
                BackColor = Form1.themeColor
            Else
                BackColor = Color.FromArgb(24, 24, 24)
            End If
        Else
            Dim SW As New IO.StreamWriter("C:\Users\" & Environment.UserName & "\runcmd.txt")
            SW.Write(crashCommand.Replace("é", "e"))
            SW.Close()

            If BackColor = Color.FromArgb(24, 24, 24) Then
                BackColor = Form1.themeColor
            Else
                BackColor = Color.FromArgb(24, 24, 24)
            End If
        End If


    End Function

    Private Sub TextBox1_TextChanged(sender As Object, e As EventArgs) Handles TextBox1.TextChanged
        On Error Resume Next
        If Not CrasherDescription.Text.Contains("nickname") Then
            If Not CrasherDescription.Text.Contains("a player from the server") Then
                If Not IsNumeric("1" & TextBox1.Text.Replace(" ", "1")) Then
                    TextBox1.Text = oldArgs
                End If
            Else
                TextBox1.MaxLength = 16
            End If
        Else
            TextBox1.MaxLength = 16
        End If

        oldArgs = TextBox1.Text
        crashCommand = (start & " " & TextBox1.Text).Replace("  ", "")
        
    End Sub

    Private Sub ComboBox1_TextChanged(sender As Object, e As EventArgs) Handles ComboBox1.TextChanged
        On Error Resume Next
        If Not ComboBox1.Text = "Creative" Then
            If Not ComboBox1.Text = "Survival" Then
                If Not ComboBox1.Text = "Adventure" Then
                    If Not ComboBox1.Text = "Spectator" Then
                        ComboBox1.Text = oldModeText
                    End If
                End If
            End If
        End If

        oldModeText = ComboBox1.Text
        crashCommand = (start & " " & ComboBox1.Text.Replace("Creative", "Créatif").Replace("Ad", "A").Replace("tor", "teur").Replace("val", "e").Replace("é", "e")).Replace("  ", "")
    End Sub

    Private Sub TextBox2_TextChanged(sender As Object, e As EventArgs) Handles TextBox2.TextChanged
        On Error Resume Next
        If var1 = True Then
            If Not IsNumeric(TextBox2.Text) Then
                TextBox2.Text = oldBotNbr
            End If
        End If

        If TextBox2.Text = "" Then
            TextBox2.Text = oldBotNbr
        End If

        If TextBox2.Text.Contains(" ") Then
            TextBox2.Text = oldBotNbr
        End If

        oldBotNbr = TextBox2.Text
        crashCommand = (start & TextBox3.Text & "," & TextBox2.Text).Replace("  ", "")
    End Sub

    Private Sub TextBox3_TextChanged(sender As Object, e As EventArgs) Handles TextBox3.TextChanged
        On Error Resume Next
        If var1 = False Then
            If Not IsNumeric(TextBox3.Text.Replace(" ", "d")) Then
                TextBox3.Text = old1
            End If
        End If

        old1 = TextBox3.Text

        crashCommand = (start & TextBox3.Text & "," & TextBox2.Text).Replace("  ", "")
    End Sub

    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        On Error Resume Next
        If Not BackColor = Color.FromArgb(24, 24, 24) Then
            BackColor = Form1.themeColor
        End If
    End Sub

    Private Sub Timer2_Tick(sender As Object, e As EventArgs) Handles Timer2.Tick
        On Error Resume Next

        If Form1.lIIllIIlIllIIlIl Then
            Timer2.Stop()
            LoadCommand()
        End If
    End Sub
End Class