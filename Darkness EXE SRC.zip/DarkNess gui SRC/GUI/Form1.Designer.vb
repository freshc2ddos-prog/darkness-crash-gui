﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form remplace la méthode Dispose pour nettoyer la liste des composants.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requise par le Concepteur Windows Form
    Private components As System.ComponentModel.IContainer

    'REMARQUE : la procédure suivante est requise par le Concepteur Windows Form
    'Elle peut être modifiée à l'aide du Concepteur Windows Form.  
    'Ne la modifiez pas à l'aide de l'éditeur de code.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.Button10 = New System.Windows.Forms.Button()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Button7 = New System.Windows.Forms.Button()
        Me.Button6 = New System.Windows.Forms.Button()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.Button4 = New System.Windows.Forms.Button()
        Me.Button5 = New System.Windows.Forms.Button()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.CrashersButton = New System.Windows.Forms.Button()
        Me.Button8 = New System.Windows.Forms.Button()
        Me.Button9 = New System.Windows.Forms.Button()
        Me.CrasherPanel = New System.Windows.Forms.Panel()
        Me.ExploitPanel = New System.Windows.Forms.Panel()
        Me.KickPanel = New System.Windows.Forms.Panel()
        Me.MovementPanel = New System.Windows.Forms.Panel()
        Me.PlayerPanel = New System.Windows.Forms.Panel()
        Me.RenderPanel = New System.Windows.Forms.Panel()
        Me.OptionsPanel = New System.Windows.Forms.Panel()
        Me.BotsPanel = New System.Windows.Forms.Panel()
        Me.ThemePanel = New System.Windows.Forms.Panel()
        Me.PictureBox2 = New System.Windows.Forms.PictureBox()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.CustomPanel = New System.Windows.Forms.Panel()
        Me.Button51 = New System.Windows.Forms.Button()
        Me.Button50 = New System.Windows.Forms.Button()
        Me.Custom6 = New System.Windows.Forms.Panel()
        Me.Label69 = New System.Windows.Forms.Label()
        Me.Button49 = New System.Windows.Forms.Button()
        Me.Label67 = New System.Windows.Forms.Label()
        Me.Button48 = New System.Windows.Forms.Button()
        Me.Label68 = New System.Windows.Forms.Label()
        Me.Button47 = New System.Windows.Forms.Button()
        Me.Button46 = New System.Windows.Forms.Button()
        Me.Button45 = New System.Windows.Forms.Button()
        Me.Button44 = New System.Windows.Forms.Button()
        Me.Button43 = New System.Windows.Forms.Button()
        Me.Custom4 = New System.Windows.Forms.Panel()
        Me.Custom3 = New System.Windows.Forms.Panel()
        Me.Custom2 = New System.Windows.Forms.Panel()
        Me.Custom5 = New System.Windows.Forms.Panel()
        Me.Custom1 = New System.Windows.Forms.Panel()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label54 = New System.Windows.Forms.Label()
        Me.Button39 = New System.Windows.Forms.Button()
        Me.Label55 = New System.Windows.Forms.Label()
        Me.Button40 = New System.Windows.Forms.Button()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label60 = New System.Windows.Forms.Label()
        Me.Label56 = New System.Windows.Forms.Label()
        Me.Label61 = New System.Windows.Forms.Label()
        Me.Button17 = New System.Windows.Forms.Button()
        Me.Button41 = New System.Windows.Forms.Button()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Button42 = New System.Windows.Forms.Button()
        Me.Button18 = New System.Windows.Forms.Button()
        Me.Label62 = New System.Windows.Forms.Label()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.Label63 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label64 = New System.Windows.Forms.Label()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.Label65 = New System.Windows.Forms.Label()
        Me.Button15 = New System.Windows.Forms.Button()
        Me.Label66 = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.Button35 = New System.Windows.Forms.Button()
        Me.Button16 = New System.Windows.Forms.Button()
        Me.Button36 = New System.Windows.Forms.Button()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.Label50 = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Label51 = New System.Windows.Forms.Label()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.Button37 = New System.Windows.Forms.Button()
        Me.Button13 = New System.Windows.Forms.Button()
        Me.Button38 = New System.Windows.Forms.Button()
        Me.Button11 = New System.Windows.Forms.Button()
        Me.Label52 = New System.Windows.Forms.Label()
        Me.Button14 = New System.Windows.Forms.Button()
        Me.Label53 = New System.Windows.Forms.Label()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.Label57 = New System.Windows.Forms.Label()
        Me.Button12 = New System.Windows.Forms.Button()
        Me.Label58 = New System.Windows.Forms.Label()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.Label59 = New System.Windows.Forms.Label()
        Me.Button31 = New System.Windows.Forms.Button()
        Me.Button32 = New System.Windows.Forms.Button()
        Me.Label43 = New System.Windows.Forms.Label()
        Me.Label44 = New System.Windows.Forms.Label()
        Me.Button33 = New System.Windows.Forms.Button()
        Me.Button34 = New System.Windows.Forms.Button()
        Me.Label45 = New System.Windows.Forms.Label()
        Me.Label46 = New System.Windows.Forms.Label()
        Me.Label47 = New System.Windows.Forms.Label()
        Me.Label48 = New System.Windows.Forms.Label()
        Me.Label49 = New System.Windows.Forms.Label()
        Me.Button27 = New System.Windows.Forms.Button()
        Me.Button28 = New System.Windows.Forms.Button()
        Me.Label33 = New System.Windows.Forms.Label()
        Me.Label34 = New System.Windows.Forms.Label()
        Me.Button29 = New System.Windows.Forms.Button()
        Me.Button30 = New System.Windows.Forms.Button()
        Me.Label38 = New System.Windows.Forms.Label()
        Me.Label39 = New System.Windows.Forms.Label()
        Me.Label40 = New System.Windows.Forms.Label()
        Me.Label41 = New System.Windows.Forms.Label()
        Me.Label42 = New System.Windows.Forms.Label()
        Me.Button23 = New System.Windows.Forms.Button()
        Me.Button24 = New System.Windows.Forms.Button()
        Me.Label24 = New System.Windows.Forms.Label()
        Me.Label25 = New System.Windows.Forms.Label()
        Me.Button25 = New System.Windows.Forms.Button()
        Me.Button26 = New System.Windows.Forms.Button()
        Me.Label26 = New System.Windows.Forms.Label()
        Me.Label27 = New System.Windows.Forms.Label()
        Me.Label35 = New System.Windows.Forms.Label()
        Me.Label36 = New System.Windows.Forms.Label()
        Me.Label37 = New System.Windows.Forms.Label()
        Me.Button19 = New System.Windows.Forms.Button()
        Me.Button20 = New System.Windows.Forms.Button()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.Label21 = New System.Windows.Forms.Label()
        Me.Button21 = New System.Windows.Forms.Button()
        Me.Button22 = New System.Windows.Forms.Button()
        Me.Label22 = New System.Windows.Forms.Label()
        Me.Label23 = New System.Windows.Forms.Label()
        Me.Label28 = New System.Windows.Forms.Label()
        Me.Label29 = New System.Windows.Forms.Label()
        Me.Label32 = New System.Windows.Forms.Label()
        Me.Panel1.SuspendLayout()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.CustomPanel.SuspendLayout()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Arial Black", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.White
        Me.Label1.Location = New System.Drawing.Point(894, 9)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(27, 18)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "✖️"
        '
        'Label2
        '
        Me.Label2.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Arial Black", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.Color.White
        Me.Label2.Location = New System.Drawing.Point(861, 9)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(27, 18)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "➖"
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.FromArgb(CType(CType(24, Byte), Integer), CType(CType(24, Byte), Integer), CType(CType(24, Byte), Integer))
        Me.Panel1.Controls.Add(Me.Button10)
        Me.Panel1.Controls.Add(Me.Label6)
        Me.Panel1.Controls.Add(Me.Button7)
        Me.Panel1.Controls.Add(Me.Button6)
        Me.Panel1.Controls.Add(Me.Label5)
        Me.Panel1.Controls.Add(Me.Label4)
        Me.Panel1.Controls.Add(Me.Label3)
        Me.Panel1.Controls.Add(Me.Button3)
        Me.Panel1.Controls.Add(Me.Button4)
        Me.Panel1.Controls.Add(Me.Button5)
        Me.Panel1.Controls.Add(Me.Button2)
        Me.Panel1.Controls.Add(Me.Button1)
        Me.Panel1.Controls.Add(Me.CrashersButton)
        Me.Panel1.Controls.Add(Me.Button8)
        Me.Panel1.Controls.Add(Me.Button9)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Left
        Me.Panel1.Location = New System.Drawing.Point(0, 0)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(154, 561)
        Me.Panel1.TabIndex = 3
        '
        'Button10
        '
        Me.Button10.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Button10.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(24, Byte), Integer), CType(CType(24, Byte), Integer), CType(CType(24, Byte), Integer))
        Me.Button10.FlatAppearance.BorderSize = 0
        Me.Button10.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(CType(CType(24, Byte), Integer), CType(CType(24, Byte), Integer), CType(CType(24, Byte), Integer))
        Me.Button10.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Black
        Me.Button10.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Black
        Me.Button10.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button10.Font = New System.Drawing.Font("Arial Black", 8.25!, System.Drawing.FontStyle.Bold)
        Me.Button10.ForeColor = System.Drawing.Color.MediumSlateBlue
        Me.Button10.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Button10.Location = New System.Drawing.Point(11, 238)
        Me.Button10.Margin = New System.Windows.Forms.Padding(2)
        Me.Button10.Name = "Button10"
        Me.Button10.Size = New System.Drawing.Size(130, 23)
        Me.Button10.TabIndex = 18
        Me.Button10.Text = " 🔥 | CUSTOM"
        Me.Button10.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Button10.UseVisualStyleBackColor = True
        '
        'Label6
        '
        Me.Label6.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Label6.Font = New System.Drawing.Font("Arial Black", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.ForeColor = System.Drawing.Color.Gray
        Me.Label6.Location = New System.Drawing.Point(12, 10)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(139, 101)
        Me.Label6.TabIndex = 15
        Me.Label6.Text = "Darkness Client"
        '
        'Button7
        '
        Me.Button7.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Button7.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(24, Byte), Integer), CType(CType(24, Byte), Integer), CType(CType(24, Byte), Integer))
        Me.Button7.FlatAppearance.BorderSize = 0
        Me.Button7.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(CType(CType(24, Byte), Integer), CType(CType(24, Byte), Integer), CType(CType(24, Byte), Integer))
        Me.Button7.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Black
        Me.Button7.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Black
        Me.Button7.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button7.Font = New System.Drawing.Font("Arial Black", 8.25!, System.Drawing.FontStyle.Bold)
        Me.Button7.ForeColor = System.Drawing.Color.MediumSlateBlue
        Me.Button7.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Button7.Location = New System.Drawing.Point(15, 454)
        Me.Button7.Margin = New System.Windows.Forms.Padding(2)
        Me.Button7.Name = "Button7"
        Me.Button7.Size = New System.Drawing.Size(126, 23)
        Me.Button7.TabIndex = 14
        Me.Button7.Text = " 🪪 | ABOUT"
        Me.Button7.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Button7.UseVisualStyleBackColor = True
        '
        'Button6
        '
        Me.Button6.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Button6.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(24, Byte), Integer), CType(CType(24, Byte), Integer), CType(CType(24, Byte), Integer))
        Me.Button6.FlatAppearance.BorderSize = 0
        Me.Button6.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(CType(CType(24, Byte), Integer), CType(CType(24, Byte), Integer), CType(CType(24, Byte), Integer))
        Me.Button6.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Black
        Me.Button6.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Black
        Me.Button6.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button6.Font = New System.Drawing.Font("Arial Black", 8.25!, System.Drawing.FontStyle.Bold)
        Me.Button6.ForeColor = System.Drawing.Color.MediumSlateBlue
        Me.Button6.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Button6.Location = New System.Drawing.Point(15, 400)
        Me.Button6.Margin = New System.Windows.Forms.Padding(2)
        Me.Button6.Name = "Button6"
        Me.Button6.Size = New System.Drawing.Size(126, 23)
        Me.Button6.TabIndex = 13
        Me.Button6.Text = " ⚙️ | OPTIONS"
        Me.Button6.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Button6.UseVisualStyleBackColor = True
        '
        'Label5
        '
        Me.Label5.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.ForeColor = System.Drawing.Color.Gray
        Me.Label5.Location = New System.Drawing.Point(12, 381)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(47, 17)
        Me.Label5.TabIndex = 12
        Me.Label5.Text = "Others"
        '
        'Label4
        '
        Me.Label4.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.ForeColor = System.Drawing.Color.Gray
        Me.Label4.Location = New System.Drawing.Point(12, 273)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(47, 17)
        Me.Label4.TabIndex = 11
        Me.Label4.Text = "Cheats"
        '
        'Label3
        '
        Me.Label3.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.ForeColor = System.Drawing.Color.Gray
        Me.Label3.Location = New System.Drawing.Point(12, 111)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(53, 17)
        Me.Label3.TabIndex = 10
        Me.Label3.Text = "Exploits"
        '
        'Button3
        '
        Me.Button3.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Button3.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(24, Byte), Integer), CType(CType(24, Byte), Integer), CType(CType(24, Byte), Integer))
        Me.Button3.FlatAppearance.BorderSize = 0
        Me.Button3.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(CType(CType(24, Byte), Integer), CType(CType(24, Byte), Integer), CType(CType(24, Byte), Integer))
        Me.Button3.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Black
        Me.Button3.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Black
        Me.Button3.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button3.Font = New System.Drawing.Font("Arial Black", 8.25!, System.Drawing.FontStyle.Bold)
        Me.Button3.ForeColor = System.Drawing.Color.MediumSlateBlue
        Me.Button3.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Button3.Location = New System.Drawing.Point(11, 346)
        Me.Button3.Margin = New System.Windows.Forms.Padding(2)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(130, 23)
        Me.Button3.TabIndex = 9
        Me.Button3.Text = " 🕶️ | RENDER"
        Me.Button3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Button3.UseVisualStyleBackColor = True
        '
        'Button4
        '
        Me.Button4.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Button4.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(24, Byte), Integer), CType(CType(24, Byte), Integer), CType(CType(24, Byte), Integer))
        Me.Button4.FlatAppearance.BorderSize = 0
        Me.Button4.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(CType(CType(24, Byte), Integer), CType(CType(24, Byte), Integer), CType(CType(24, Byte), Integer))
        Me.Button4.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Black
        Me.Button4.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Black
        Me.Button4.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button4.Font = New System.Drawing.Font("Arial Black", 8.25!, System.Drawing.FontStyle.Bold)
        Me.Button4.ForeColor = System.Drawing.Color.MediumSlateBlue
        Me.Button4.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Button4.Location = New System.Drawing.Point(11, 319)
        Me.Button4.Margin = New System.Windows.Forms.Padding(2)
        Me.Button4.Name = "Button4"
        Me.Button4.Size = New System.Drawing.Size(130, 23)
        Me.Button4.TabIndex = 8
        Me.Button4.Text = " 🖱️ | PLAYER"
        Me.Button4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Button4.UseVisualStyleBackColor = True
        '
        'Button5
        '
        Me.Button5.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Button5.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(24, Byte), Integer), CType(CType(24, Byte), Integer), CType(CType(24, Byte), Integer))
        Me.Button5.FlatAppearance.BorderSize = 0
        Me.Button5.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(CType(CType(24, Byte), Integer), CType(CType(24, Byte), Integer), CType(CType(24, Byte), Integer))
        Me.Button5.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Black
        Me.Button5.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Black
        Me.Button5.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button5.Font = New System.Drawing.Font("Arial Black", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button5.ForeColor = System.Drawing.Color.MediumSlateBlue
        Me.Button5.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Button5.Location = New System.Drawing.Point(11, 292)
        Me.Button5.Margin = New System.Windows.Forms.Padding(2)
        Me.Button5.Name = "Button5"
        Me.Button5.Size = New System.Drawing.Size(130, 23)
        Me.Button5.TabIndex = 7
        Me.Button5.Text = " 🌍 | MOVEMENT"
        Me.Button5.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Button5.UseVisualStyleBackColor = True
        '
        'Button2
        '
        Me.Button2.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Button2.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(24, Byte), Integer), CType(CType(24, Byte), Integer), CType(CType(24, Byte), Integer))
        Me.Button2.FlatAppearance.BorderSize = 0
        Me.Button2.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(CType(CType(24, Byte), Integer), CType(CType(24, Byte), Integer), CType(CType(24, Byte), Integer))
        Me.Button2.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Black
        Me.Button2.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Black
        Me.Button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button2.Font = New System.Drawing.Font("Arial Black", 8.25!, System.Drawing.FontStyle.Bold)
        Me.Button2.ForeColor = System.Drawing.Color.MediumSlateBlue
        Me.Button2.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Button2.Location = New System.Drawing.Point(11, 184)
        Me.Button2.Margin = New System.Windows.Forms.Padding(2)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(130, 23)
        Me.Button2.TabIndex = 6
        Me.Button2.Text = " 🤖 | BOTS"
        Me.Button2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Button2.UseVisualStyleBackColor = True
        '
        'Button1
        '
        Me.Button1.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Button1.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(24, Byte), Integer), CType(CType(24, Byte), Integer), CType(CType(24, Byte), Integer))
        Me.Button1.FlatAppearance.BorderSize = 0
        Me.Button1.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(CType(CType(24, Byte), Integer), CType(CType(24, Byte), Integer), CType(CType(24, Byte), Integer))
        Me.Button1.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Black
        Me.Button1.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Black
        Me.Button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button1.Font = New System.Drawing.Font("Arial Black", 8.25!, System.Drawing.FontStyle.Bold)
        Me.Button1.ForeColor = System.Drawing.Color.MediumSlateBlue
        Me.Button1.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Button1.Location = New System.Drawing.Point(11, 157)
        Me.Button1.Margin = New System.Windows.Forms.Padding(2)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(130, 23)
        Me.Button1.TabIndex = 5
        Me.Button1.Text = " 💻 | EXPLOITS"
        Me.Button1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Button1.UseVisualStyleBackColor = True
        '
        'CrashersButton
        '
        Me.CrashersButton.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.CrashersButton.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(24, Byte), Integer), CType(CType(24, Byte), Integer), CType(CType(24, Byte), Integer))
        Me.CrashersButton.FlatAppearance.BorderSize = 0
        Me.CrashersButton.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(CType(CType(24, Byte), Integer), CType(CType(24, Byte), Integer), CType(CType(24, Byte), Integer))
        Me.CrashersButton.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Black
        Me.CrashersButton.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Black
        Me.CrashersButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.CrashersButton.Font = New System.Drawing.Font("Arial Black", 8.25!, System.Drawing.FontStyle.Bold)
        Me.CrashersButton.ForeColor = System.Drawing.Color.MediumSlateBlue
        Me.CrashersButton.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.CrashersButton.Location = New System.Drawing.Point(11, 130)
        Me.CrashersButton.Margin = New System.Windows.Forms.Padding(2)
        Me.CrashersButton.Name = "CrashersButton"
        Me.CrashersButton.Size = New System.Drawing.Size(130, 23)
        Me.CrashersButton.TabIndex = 4
        Me.CrashersButton.Text = " 🔥 | CRASHERS"
        Me.CrashersButton.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.CrashersButton.UseVisualStyleBackColor = True
        '
        'Button8
        '
        Me.Button8.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Button8.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(24, Byte), Integer), CType(CType(24, Byte), Integer), CType(CType(24, Byte), Integer))
        Me.Button8.FlatAppearance.BorderSize = 0
        Me.Button8.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(CType(CType(24, Byte), Integer), CType(CType(24, Byte), Integer), CType(CType(24, Byte), Integer))
        Me.Button8.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Black
        Me.Button8.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Black
        Me.Button8.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button8.Font = New System.Drawing.Font("Arial Black", 8.25!, System.Drawing.FontStyle.Bold)
        Me.Button8.ForeColor = System.Drawing.Color.MediumSlateBlue
        Me.Button8.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Button8.Location = New System.Drawing.Point(11, 211)
        Me.Button8.Margin = New System.Windows.Forms.Padding(2)
        Me.Button8.Name = "Button8"
        Me.Button8.Size = New System.Drawing.Size(130, 23)
        Me.Button8.TabIndex = 16
        Me.Button8.Text = " 🚀 | KICK"
        Me.Button8.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Button8.UseVisualStyleBackColor = True
        '
        'Button9
        '
        Me.Button9.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Button9.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(24, Byte), Integer), CType(CType(24, Byte), Integer), CType(CType(24, Byte), Integer))
        Me.Button9.FlatAppearance.BorderSize = 0
        Me.Button9.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(CType(CType(24, Byte), Integer), CType(CType(24, Byte), Integer), CType(CType(24, Byte), Integer))
        Me.Button9.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Black
        Me.Button9.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Black
        Me.Button9.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button9.Font = New System.Drawing.Font("Arial Black", 8.25!, System.Drawing.FontStyle.Bold)
        Me.Button9.ForeColor = System.Drawing.Color.MediumSlateBlue
        Me.Button9.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Button9.Location = New System.Drawing.Point(15, 427)
        Me.Button9.Margin = New System.Windows.Forms.Padding(2)
        Me.Button9.Name = "Button9"
        Me.Button9.Size = New System.Drawing.Size(126, 23)
        Me.Button9.TabIndex = 17
        Me.Button9.Text = " 🪶 | THEME"
        Me.Button9.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Button9.UseVisualStyleBackColor = True
        '
        'CrasherPanel
        '
        Me.CrasherPanel.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.CrasherPanel.AutoScroll = True
        Me.CrasherPanel.Location = New System.Drawing.Point(166, 88)
        Me.CrasherPanel.Name = "CrasherPanel"
        Me.CrasherPanel.Size = New System.Drawing.Size(749, 461)
        Me.CrasherPanel.TabIndex = 5
        Me.CrasherPanel.Visible = False
        '
        'ExploitPanel
        '
        Me.ExploitPanel.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.ExploitPanel.AutoScroll = True
        Me.ExploitPanel.Location = New System.Drawing.Point(166, 88)
        Me.ExploitPanel.Name = "ExploitPanel"
        Me.ExploitPanel.Size = New System.Drawing.Size(749, 461)
        Me.ExploitPanel.TabIndex = 6
        Me.ExploitPanel.Visible = False
        '
        'KickPanel
        '
        Me.KickPanel.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.KickPanel.AutoScroll = True
        Me.KickPanel.Location = New System.Drawing.Point(166, 88)
        Me.KickPanel.Name = "KickPanel"
        Me.KickPanel.Size = New System.Drawing.Size(749, 461)
        Me.KickPanel.TabIndex = 7
        Me.KickPanel.Visible = False
        '
        'MovementPanel
        '
        Me.MovementPanel.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.MovementPanel.AutoScroll = True
        Me.MovementPanel.Location = New System.Drawing.Point(166, 88)
        Me.MovementPanel.Name = "MovementPanel"
        Me.MovementPanel.Size = New System.Drawing.Size(749, 461)
        Me.MovementPanel.TabIndex = 8
        Me.MovementPanel.Visible = False
        '
        'PlayerPanel
        '
        Me.PlayerPanel.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.PlayerPanel.AutoScroll = True
        Me.PlayerPanel.Location = New System.Drawing.Point(166, 88)
        Me.PlayerPanel.Name = "PlayerPanel"
        Me.PlayerPanel.Size = New System.Drawing.Size(749, 461)
        Me.PlayerPanel.TabIndex = 9
        Me.PlayerPanel.Visible = False
        '
        'RenderPanel
        '
        Me.RenderPanel.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.RenderPanel.AutoScroll = True
        Me.RenderPanel.Location = New System.Drawing.Point(166, 88)
        Me.RenderPanel.Name = "RenderPanel"
        Me.RenderPanel.Size = New System.Drawing.Size(749, 461)
        Me.RenderPanel.TabIndex = 10
        Me.RenderPanel.Visible = False
        '
        'OptionsPanel
        '
        Me.OptionsPanel.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.OptionsPanel.AutoScroll = True
        Me.OptionsPanel.Location = New System.Drawing.Point(166, 88)
        Me.OptionsPanel.Name = "OptionsPanel"
        Me.OptionsPanel.Size = New System.Drawing.Size(749, 461)
        Me.OptionsPanel.TabIndex = 11
        Me.OptionsPanel.Visible = False
        '
        'BotsPanel
        '
        Me.BotsPanel.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.BotsPanel.AutoScroll = True
        Me.BotsPanel.Location = New System.Drawing.Point(166, 88)
        Me.BotsPanel.Name = "BotsPanel"
        Me.BotsPanel.Size = New System.Drawing.Size(749, 461)
        Me.BotsPanel.TabIndex = 12
        Me.BotsPanel.Visible = False
        '
        'ThemePanel
        '
        Me.ThemePanel.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.ThemePanel.AutoScroll = True
        Me.ThemePanel.Location = New System.Drawing.Point(166, 88)
        Me.ThemePanel.Name = "ThemePanel"
        Me.ThemePanel.Size = New System.Drawing.Size(749, 461)
        Me.ThemePanel.TabIndex = 13
        Me.ThemePanel.Visible = False
        '
        'PictureBox2
        '
        Me.PictureBox2.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.PictureBox2.Image = Global.Darkness.My.Resources.Resources.logo2
        Me.PictureBox2.Location = New System.Drawing.Point(553, 40)
        Me.PictureBox2.Name = "PictureBox2"
        Me.PictureBox2.Size = New System.Drawing.Size(98, 28)
        Me.PictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox2.TabIndex = 4
        Me.PictureBox2.TabStop = False
        '
        'PictureBox1
        '
        Me.PictureBox1.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.PictureBox1.Image = Global.Darkness.My.Resources.Resources.logored
        Me.PictureBox1.Location = New System.Drawing.Point(363, 15)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(201, 40)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox1.TabIndex = 2
        Me.PictureBox1.TabStop = False
        '
        'CustomPanel
        '
        Me.CustomPanel.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.CustomPanel.AutoScroll = True
        Me.CustomPanel.Controls.Add(Me.Button51)
        Me.CustomPanel.Controls.Add(Me.Button50)
        Me.CustomPanel.Controls.Add(Me.Custom6)
        Me.CustomPanel.Controls.Add(Me.Label69)
        Me.CustomPanel.Controls.Add(Me.Button49)
        Me.CustomPanel.Controls.Add(Me.Label67)
        Me.CustomPanel.Controls.Add(Me.Button48)
        Me.CustomPanel.Controls.Add(Me.Label68)
        Me.CustomPanel.Controls.Add(Me.Button47)
        Me.CustomPanel.Controls.Add(Me.Button46)
        Me.CustomPanel.Controls.Add(Me.Button45)
        Me.CustomPanel.Controls.Add(Me.Button44)
        Me.CustomPanel.Controls.Add(Me.Button43)
        Me.CustomPanel.Controls.Add(Me.Custom4)
        Me.CustomPanel.Controls.Add(Me.Custom3)
        Me.CustomPanel.Controls.Add(Me.Custom2)
        Me.CustomPanel.Controls.Add(Me.Custom5)
        Me.CustomPanel.Controls.Add(Me.Custom1)
        Me.CustomPanel.Controls.Add(Me.Label7)
        Me.CustomPanel.Controls.Add(Me.Label8)
        Me.CustomPanel.Controls.Add(Me.Label54)
        Me.CustomPanel.Controls.Add(Me.Button39)
        Me.CustomPanel.Controls.Add(Me.Label55)
        Me.CustomPanel.Controls.Add(Me.Button40)
        Me.CustomPanel.Controls.Add(Me.Label9)
        Me.CustomPanel.Controls.Add(Me.Label60)
        Me.CustomPanel.Controls.Add(Me.Label56)
        Me.CustomPanel.Controls.Add(Me.Label61)
        Me.CustomPanel.Controls.Add(Me.Button17)
        Me.CustomPanel.Controls.Add(Me.Button41)
        Me.CustomPanel.Controls.Add(Me.Label11)
        Me.CustomPanel.Controls.Add(Me.Button42)
        Me.CustomPanel.Controls.Add(Me.Button18)
        Me.CustomPanel.Controls.Add(Me.Label62)
        Me.CustomPanel.Controls.Add(Me.Label18)
        Me.CustomPanel.Controls.Add(Me.Label63)
        Me.CustomPanel.Controls.Add(Me.Label10)
        Me.CustomPanel.Controls.Add(Me.Label64)
        Me.CustomPanel.Controls.Add(Me.Label19)
        Me.CustomPanel.Controls.Add(Me.Label65)
        Me.CustomPanel.Controls.Add(Me.Button15)
        Me.CustomPanel.Controls.Add(Me.Label66)
        Me.CustomPanel.Controls.Add(Me.Label13)
        Me.CustomPanel.Controls.Add(Me.Button35)
        Me.CustomPanel.Controls.Add(Me.Button16)
        Me.CustomPanel.Controls.Add(Me.Button36)
        Me.CustomPanel.Controls.Add(Me.Label16)
        Me.CustomPanel.Controls.Add(Me.Label50)
        Me.CustomPanel.Controls.Add(Me.Label12)
        Me.CustomPanel.Controls.Add(Me.Label51)
        Me.CustomPanel.Controls.Add(Me.Label17)
        Me.CustomPanel.Controls.Add(Me.Button37)
        Me.CustomPanel.Controls.Add(Me.Button13)
        Me.CustomPanel.Controls.Add(Me.Button38)
        Me.CustomPanel.Controls.Add(Me.Button11)
        Me.CustomPanel.Controls.Add(Me.Label52)
        Me.CustomPanel.Controls.Add(Me.Button14)
        Me.CustomPanel.Controls.Add(Me.Label53)
        Me.CustomPanel.Controls.Add(Me.Label14)
        Me.CustomPanel.Controls.Add(Me.Label57)
        Me.CustomPanel.Controls.Add(Me.Button12)
        Me.CustomPanel.Controls.Add(Me.Label58)
        Me.CustomPanel.Controls.Add(Me.Label15)
        Me.CustomPanel.Controls.Add(Me.Label59)
        Me.CustomPanel.Controls.Add(Me.Button31)
        Me.CustomPanel.Controls.Add(Me.Button32)
        Me.CustomPanel.Controls.Add(Me.Label43)
        Me.CustomPanel.Controls.Add(Me.Label44)
        Me.CustomPanel.Controls.Add(Me.Button33)
        Me.CustomPanel.Controls.Add(Me.Button34)
        Me.CustomPanel.Controls.Add(Me.Label45)
        Me.CustomPanel.Controls.Add(Me.Label46)
        Me.CustomPanel.Controls.Add(Me.Label47)
        Me.CustomPanel.Controls.Add(Me.Label48)
        Me.CustomPanel.Controls.Add(Me.Label49)
        Me.CustomPanel.Controls.Add(Me.Button27)
        Me.CustomPanel.Controls.Add(Me.Button28)
        Me.CustomPanel.Controls.Add(Me.Label33)
        Me.CustomPanel.Controls.Add(Me.Label34)
        Me.CustomPanel.Controls.Add(Me.Button29)
        Me.CustomPanel.Controls.Add(Me.Button30)
        Me.CustomPanel.Controls.Add(Me.Label38)
        Me.CustomPanel.Controls.Add(Me.Label39)
        Me.CustomPanel.Controls.Add(Me.Label40)
        Me.CustomPanel.Controls.Add(Me.Label41)
        Me.CustomPanel.Controls.Add(Me.Label42)
        Me.CustomPanel.Controls.Add(Me.Button23)
        Me.CustomPanel.Controls.Add(Me.Button24)
        Me.CustomPanel.Controls.Add(Me.Label24)
        Me.CustomPanel.Controls.Add(Me.Label25)
        Me.CustomPanel.Controls.Add(Me.Button25)
        Me.CustomPanel.Controls.Add(Me.Button26)
        Me.CustomPanel.Controls.Add(Me.Label26)
        Me.CustomPanel.Controls.Add(Me.Label27)
        Me.CustomPanel.Controls.Add(Me.Label35)
        Me.CustomPanel.Controls.Add(Me.Label36)
        Me.CustomPanel.Controls.Add(Me.Label37)
        Me.CustomPanel.Controls.Add(Me.Button19)
        Me.CustomPanel.Controls.Add(Me.Button20)
        Me.CustomPanel.Controls.Add(Me.Label20)
        Me.CustomPanel.Controls.Add(Me.Label21)
        Me.CustomPanel.Controls.Add(Me.Button21)
        Me.CustomPanel.Controls.Add(Me.Button22)
        Me.CustomPanel.Controls.Add(Me.Label22)
        Me.CustomPanel.Controls.Add(Me.Label23)
        Me.CustomPanel.Controls.Add(Me.Label28)
        Me.CustomPanel.Controls.Add(Me.Label29)
        Me.CustomPanel.Controls.Add(Me.Label32)
        Me.CustomPanel.Location = New System.Drawing.Point(166, 88)
        Me.CustomPanel.Name = "CustomPanel"
        Me.CustomPanel.Size = New System.Drawing.Size(749, 461)
        Me.CustomPanel.TabIndex = 14
        Me.CustomPanel.Visible = False
        '
        'Button51
        '
        Me.Button51.BackColor = System.Drawing.Color.Black
        Me.Button51.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(32, Byte), Integer), CType(CType(32, Byte), Integer))
        Me.Button51.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button51.Font = New System.Drawing.Font("Segoe UI Black", 9.25!, System.Drawing.FontStyle.Bold)
        Me.Button51.ForeColor = System.Drawing.Color.White
        Me.Button51.Location = New System.Drawing.Point(469, 420)
        Me.Button51.Name = "Button51"
        Me.Button51.Size = New System.Drawing.Size(148, 28)
        Me.Button51.TabIndex = 118
        Me.Button51.Text = "Send packets"
        Me.Button51.UseVisualStyleBackColor = False
        '
        'Button50
        '
        Me.Button50.BackColor = System.Drawing.Color.Black
        Me.Button50.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(32, Byte), Integer), CType(CType(32, Byte), Integer))
        Me.Button50.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button50.Font = New System.Drawing.Font("Segoe UI Black", 9.25!, System.Drawing.FontStyle.Bold)
        Me.Button50.ForeColor = System.Drawing.Color.White
        Me.Button50.Location = New System.Drawing.Point(56, 127)
        Me.Button50.Name = "Button50"
        Me.Button50.Size = New System.Drawing.Size(162, 25)
        Me.Button50.TabIndex = 113
        Me.Button50.Text = "Send packets"
        Me.Button50.UseVisualStyleBackColor = False
        '
        'Custom6
        '
        Me.Custom6.BackColor = System.Drawing.Color.MediumSlateBlue
        Me.Custom6.Location = New System.Drawing.Point(456, 359)
        Me.Custom6.Name = "Custom6"
        Me.Custom6.Size = New System.Drawing.Size(200, 2)
        Me.Custom6.TabIndex = 117
        '
        'Label69
        '
        Me.Label69.AutoSize = True
        Me.Label69.Font = New System.Drawing.Font("Arial Black", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label69.ForeColor = System.Drawing.Color.White
        Me.Label69.Location = New System.Drawing.Point(466, 368)
        Me.Label69.Name = "Label69"
        Me.Label69.Size = New System.Drawing.Size(171, 18)
        Me.Label69.TabIndex = 114
        Me.Label69.Text = "LUCKPERMS CRASHER"
        '
        'Button49
        '
        Me.Button49.BackColor = System.Drawing.Color.Black
        Me.Button49.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(32, Byte), Integer), CType(CType(32, Byte), Integer))
        Me.Button49.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button49.Font = New System.Drawing.Font("Segoe UI Black", 9.25!, System.Drawing.FontStyle.Bold)
        Me.Button49.ForeColor = System.Drawing.Color.White
        Me.Button49.Location = New System.Drawing.Point(56, 263)
        Me.Button49.Name = "Button49"
        Me.Button49.Size = New System.Drawing.Size(162, 25)
        Me.Button49.TabIndex = 112
        Me.Button49.Text = "Send packets"
        Me.Button49.UseVisualStyleBackColor = False
        '
        'Label67
        '
        Me.Label67.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label67.ForeColor = System.Drawing.Color.Gray
        Me.Label67.Location = New System.Drawing.Point(525, 394)
        Me.Label67.Name = "Label67"
        Me.Label67.Size = New System.Drawing.Size(100, 16)
        Me.Label67.TabIndex = 116
        Me.Label67.Text = "LPB-Hard"
        '
        'Button48
        '
        Me.Button48.BackColor = System.Drawing.Color.Black
        Me.Button48.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(32, Byte), Integer), CType(CType(32, Byte), Integer))
        Me.Button48.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button48.Font = New System.Drawing.Font("Segoe UI Black", 9.25!, System.Drawing.FontStyle.Bold)
        Me.Button48.ForeColor = System.Drawing.Color.White
        Me.Button48.Location = New System.Drawing.Point(259, 263)
        Me.Button48.Name = "Button48"
        Me.Button48.Size = New System.Drawing.Size(175, 25)
        Me.Button48.TabIndex = 111
        Me.Button48.Text = "Send packets"
        Me.Button48.UseVisualStyleBackColor = False
        '
        'Label68
        '
        Me.Label68.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label68.ForeColor = System.Drawing.Color.White
        Me.Label68.Location = New System.Drawing.Point(466, 394)
        Me.Label68.Name = "Label68"
        Me.Label68.Size = New System.Drawing.Size(53, 16)
        Me.Label68.TabIndex = 115
        Me.Label68.Text = "Mode »"
        '
        'Button47
        '
        Me.Button47.BackColor = System.Drawing.Color.Black
        Me.Button47.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(32, Byte), Integer), CType(CType(32, Byte), Integer))
        Me.Button47.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button47.Font = New System.Drawing.Font("Segoe UI Black", 9.25!, System.Drawing.FontStyle.Bold)
        Me.Button47.ForeColor = System.Drawing.Color.White
        Me.Button47.Location = New System.Drawing.Point(259, 123)
        Me.Button47.Name = "Button47"
        Me.Button47.Size = New System.Drawing.Size(175, 28)
        Me.Button47.TabIndex = 110
        Me.Button47.Text = "Send packets"
        Me.Button47.UseVisualStyleBackColor = False
        '
        'Button46
        '
        Me.Button46.BackColor = System.Drawing.Color.Black
        Me.Button46.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(32, Byte), Integer), CType(CType(32, Byte), Integer))
        Me.Button46.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button46.Font = New System.Drawing.Font("Segoe UI Black", 9.25!, System.Drawing.FontStyle.Bold)
        Me.Button46.ForeColor = System.Drawing.Color.White
        Me.Button46.Location = New System.Drawing.Point(56, 416)
        Me.Button46.Name = "Button46"
        Me.Button46.Size = New System.Drawing.Size(162, 28)
        Me.Button46.TabIndex = 109
        Me.Button46.Text = "Send packets"
        Me.Button46.UseVisualStyleBackColor = False
        '
        'Button45
        '
        Me.Button45.BackColor = System.Drawing.Color.Black
        Me.Button45.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(32, Byte), Integer), CType(CType(32, Byte), Integer))
        Me.Button45.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button45.Font = New System.Drawing.Font("Segoe UI Black", 9.25!, System.Drawing.FontStyle.Bold)
        Me.Button45.ForeColor = System.Drawing.Color.White
        Me.Button45.Location = New System.Drawing.Point(259, 416)
        Me.Button45.Name = "Button45"
        Me.Button45.Size = New System.Drawing.Size(175, 28)
        Me.Button45.TabIndex = 108
        Me.Button45.Text = "Send packets"
        Me.Button45.UseVisualStyleBackColor = False
        '
        'Button44
        '
        Me.Button44.BackColor = System.Drawing.Color.Black
        Me.Button44.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(32, Byte), Integer), CType(CType(32, Byte), Integer))
        Me.Button44.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button44.Font = New System.Drawing.Font("Segoe UI Black", 9.25!, System.Drawing.FontStyle.Bold)
        Me.Button44.ForeColor = System.Drawing.Color.White
        Me.Button44.Location = New System.Drawing.Point(469, 217)
        Me.Button44.Name = "Button44"
        Me.Button44.Size = New System.Drawing.Size(148, 28)
        Me.Button44.TabIndex = 107
        Me.Button44.Text = "Send packets"
        Me.Button44.UseVisualStyleBackColor = False
        '
        'Button43
        '
        Me.Button43.BackColor = System.Drawing.Color.Black
        Me.Button43.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(32, Byte), Integer), CType(CType(32, Byte), Integer))
        Me.Button43.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button43.Font = New System.Drawing.Font("Segoe UI Black", 9.25!, System.Drawing.FontStyle.Bold)
        Me.Button43.ForeColor = System.Drawing.Color.White
        Me.Button43.Location = New System.Drawing.Point(469, 322)
        Me.Button43.Name = "Button43"
        Me.Button43.Size = New System.Drawing.Size(148, 28)
        Me.Button43.TabIndex = 106
        Me.Button43.Text = "Send packets"
        Me.Button43.UseVisualStyleBackColor = False
        '
        'Custom4
        '
        Me.Custom4.BackColor = System.Drawing.Color.MediumSlateBlue
        Me.Custom4.Location = New System.Drawing.Point(456, 257)
        Me.Custom4.Name = "Custom4"
        Me.Custom4.Size = New System.Drawing.Size(200, 2)
        Me.Custom4.TabIndex = 104
        '
        'Custom3
        '
        Me.Custom3.BackColor = System.Drawing.Color.MediumSlateBlue
        Me.Custom3.Location = New System.Drawing.Point(454, 13)
        Me.Custom3.Name = "Custom3"
        Me.Custom3.Size = New System.Drawing.Size(2, 433)
        Me.Custom3.TabIndex = 105
        '
        'Custom2
        '
        Me.Custom2.BackColor = System.Drawing.Color.MediumSlateBlue
        Me.Custom2.Location = New System.Drawing.Point(236, 13)
        Me.Custom2.Name = "Custom2"
        Me.Custom2.Size = New System.Drawing.Size(2, 433)
        Me.Custom2.TabIndex = 104
        '
        'Custom5
        '
        Me.Custom5.BackColor = System.Drawing.Color.MediumSlateBlue
        Me.Custom5.Location = New System.Drawing.Point(56, 294)
        Me.Custom5.Name = "Custom5"
        Me.Custom5.Size = New System.Drawing.Size(400, 2)
        Me.Custom5.TabIndex = 103
        '
        'Custom1
        '
        Me.Custom1.BackColor = System.Drawing.Color.MediumSlateBlue
        Me.Custom1.Location = New System.Drawing.Point(56, 158)
        Me.Custom1.Name = "Custom1"
        Me.Custom1.Size = New System.Drawing.Size(400, 2)
        Me.Custom1.TabIndex = 102
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Arial Black", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.ForeColor = System.Drawing.Color.White
        Me.Label7.Location = New System.Drawing.Point(466, 18)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(158, 18)
        Me.Label7.TabIndex = 0
        Me.Label7.Text = "BOOK NBT CRASHER"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.ForeColor = System.Drawing.Color.White
        Me.Label8.Location = New System.Drawing.Point(466, 44)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(89, 16)
        Me.Label8.TabIndex = 1
        Me.Label8.Text = "Packet type »"
        '
        'Label54
        '
        Me.Label54.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label54.ForeColor = System.Drawing.Color.Gray
        Me.Label54.Location = New System.Drawing.Point(525, 296)
        Me.Label54.Name = "Label54"
        Me.Label54.Size = New System.Drawing.Size(154, 16)
        Me.Label54.TabIndex = 79
        Me.Label54.Text = "OldJartex"
        '
        'Button39
        '
        Me.Button39.FlatAppearance.BorderSize = 0
        Me.Button39.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button39.Font = New System.Drawing.Font("Arial Black", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button39.ForeColor = System.Drawing.Color.White
        Me.Button39.Location = New System.Drawing.Point(390, 379)
        Me.Button39.Name = "Button39"
        Me.Button39.Size = New System.Drawing.Size(20, 31)
        Me.Button39.TabIndex = 101
        Me.Button39.Text = "↓"
        Me.Button39.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Button39.UseVisualStyleBackColor = True
        '
        'Label55
        '
        Me.Label55.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label55.ForeColor = System.Drawing.Color.White
        Me.Label55.Location = New System.Drawing.Point(466, 296)
        Me.Label55.Name = "Label55"
        Me.Label55.Size = New System.Drawing.Size(53, 16)
        Me.Label55.TabIndex = 78
        Me.Label55.Text = "Mode »"
        '
        'Button40
        '
        Me.Button40.FlatAppearance.BorderSize = 0
        Me.Button40.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button40.Font = New System.Drawing.Font("Arial Black", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button40.ForeColor = System.Drawing.Color.White
        Me.Button40.Location = New System.Drawing.Point(370, 379)
        Me.Button40.Name = "Button40"
        Me.Button40.Size = New System.Drawing.Size(20, 31)
        Me.Button40.TabIndex = 100
        Me.Button40.Text = "↑"
        Me.Button40.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Button40.UseVisualStyleBackColor = True
        '
        'Label9
        '
        Me.Label9.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.ForeColor = System.Drawing.Color.Gray
        Me.Label9.Location = New System.Drawing.Point(552, 44)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(179, 16)
        Me.Label9.TabIndex = 2
        Me.Label9.Text = "WindowClick"
        '
        'Label60
        '
        Me.Label60.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label60.ForeColor = System.Drawing.Color.Gray
        Me.Label60.Location = New System.Drawing.Point(316, 388)
        Me.Label60.Name = "Label60"
        Me.Label60.Size = New System.Drawing.Size(56, 16)
        Me.Label60.TabIndex = 99
        Me.Label60.Text = "0ms"
        '
        'Label56
        '
        Me.Label56.AutoSize = True
        Me.Label56.Font = New System.Drawing.Font("Arial Black", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label56.ForeColor = System.Drawing.Color.White
        Me.Label56.Location = New System.Drawing.Point(466, 270)
        Me.Label56.Name = "Label56"
        Me.Label56.Size = New System.Drawing.Size(151, 18)
        Me.Label56.TabIndex = 77
        Me.Label56.Text = "POSITION CRASHER"
        '
        'Label61
        '
        Me.Label61.AutoSize = True
        Me.Label61.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label61.ForeColor = System.Drawing.Color.White
        Me.Label61.Location = New System.Drawing.Point(256, 388)
        Me.Label61.Name = "Label61"
        Me.Label61.Size = New System.Drawing.Size(54, 16)
        Me.Label61.TabIndex = 98
        Me.Label61.Text = "Delay »"
        '
        'Button17
        '
        Me.Button17.FlatAppearance.BorderSize = 0
        Me.Button17.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button17.Font = New System.Drawing.Font("Arial Black", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button17.ForeColor = System.Drawing.Color.White
        Me.Button17.Location = New System.Drawing.Point(600, 179)
        Me.Button17.Name = "Button17"
        Me.Button17.Size = New System.Drawing.Size(20, 31)
        Me.Button17.TabIndex = 20
        Me.Button17.Text = "↓"
        Me.Button17.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Button17.UseVisualStyleBackColor = True
        '
        'Button41
        '
        Me.Button41.FlatAppearance.BorderSize = 0
        Me.Button41.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button41.Font = New System.Drawing.Font("Arial Black", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button41.ForeColor = System.Drawing.Color.White
        Me.Button41.Location = New System.Drawing.Point(390, 355)
        Me.Button41.Name = "Button41"
        Me.Button41.Size = New System.Drawing.Size(20, 31)
        Me.Button41.TabIndex = 97
        Me.Button41.Text = "↓"
        Me.Button41.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Button41.UseVisualStyleBackColor = True
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label11.ForeColor = System.Drawing.Color.White
        Me.Label11.Location = New System.Drawing.Point(466, 65)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(46, 16)
        Me.Label11.TabIndex = 3
        Me.Label11.Text = "NBT »"
        '
        'Button42
        '
        Me.Button42.FlatAppearance.BorderSize = 0
        Me.Button42.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button42.Font = New System.Drawing.Font("Arial Black", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button42.ForeColor = System.Drawing.Color.White
        Me.Button42.Location = New System.Drawing.Point(370, 355)
        Me.Button42.Name = "Button42"
        Me.Button42.Size = New System.Drawing.Size(20, 31)
        Me.Button42.TabIndex = 96
        Me.Button42.Text = "↑"
        Me.Button42.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Button42.UseVisualStyleBackColor = True
        '
        'Button18
        '
        Me.Button18.FlatAppearance.BorderSize = 0
        Me.Button18.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button18.Font = New System.Drawing.Font("Arial Black", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button18.ForeColor = System.Drawing.Color.White
        Me.Button18.Location = New System.Drawing.Point(580, 179)
        Me.Button18.Name = "Button18"
        Me.Button18.Size = New System.Drawing.Size(20, 31)
        Me.Button18.TabIndex = 19
        Me.Button18.Text = "↑"
        Me.Button18.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Button18.UseVisualStyleBackColor = True
        '
        'Label62
        '
        Me.Label62.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label62.ForeColor = System.Drawing.Color.Gray
        Me.Label62.Location = New System.Drawing.Point(325, 364)
        Me.Label62.Name = "Label62"
        Me.Label62.Size = New System.Drawing.Size(47, 16)
        Me.Label62.TabIndex = 95
        Me.Label62.Text = "2500"
        '
        'Label18
        '
        Me.Label18.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label18.ForeColor = System.Drawing.Color.Gray
        Me.Label18.Location = New System.Drawing.Point(526, 188)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(48, 16)
        Me.Label18.TabIndex = 18
        Me.Label18.Text = "5ms"
        '
        'Label63
        '
        Me.Label63.AutoSize = True
        Me.Label63.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label63.ForeColor = System.Drawing.Color.White
        Me.Label63.Location = New System.Drawing.Point(256, 364)
        Me.Label63.Name = "Label63"
        Me.Label63.Size = New System.Drawing.Size(67, 16)
        Me.Label63.TabIndex = 94
        Me.Label63.Text = "Packets »"
        '
        'Label10
        '
        Me.Label10.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.ForeColor = System.Drawing.Color.Gray
        Me.Label10.Location = New System.Drawing.Point(518, 65)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(190, 16)
        Me.Label10.TabIndex = 4
        Me.Label10.Text = "Extra (A)"
        Me.Label10.TextAlign = System.Drawing.ContentAlignment.BottomLeft
        '
        'Label64
        '
        Me.Label64.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label64.ForeColor = System.Drawing.Color.Gray
        Me.Label64.Location = New System.Drawing.Point(315, 331)
        Me.Label64.Name = "Label64"
        Me.Label64.Size = New System.Drawing.Size(100, 16)
        Me.Label64.TabIndex = 93
        Me.Label64.Text = "Creative (Drop)"
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label19.ForeColor = System.Drawing.Color.White
        Me.Label19.Location = New System.Drawing.Point(466, 188)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(54, 16)
        Me.Label19.TabIndex = 17
        Me.Label19.Text = "Delay »"
        '
        'Label65
        '
        Me.Label65.AutoSize = True
        Me.Label65.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label65.ForeColor = System.Drawing.Color.White
        Me.Label65.Location = New System.Drawing.Point(256, 331)
        Me.Label65.Name = "Label65"
        Me.Label65.Size = New System.Drawing.Size(60, 16)
        Me.Label65.TabIndex = 92
        Me.Label65.Text = "Packet »"
        '
        'Button15
        '
        Me.Button15.FlatAppearance.BorderSize = 0
        Me.Button15.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button15.Font = New System.Drawing.Font("Arial Black", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button15.ForeColor = System.Drawing.Color.White
        Me.Button15.Location = New System.Drawing.Point(600, 155)
        Me.Button15.Name = "Button15"
        Me.Button15.Size = New System.Drawing.Size(20, 31)
        Me.Button15.TabIndex = 16
        Me.Button15.Text = "↓"
        Me.Button15.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Button15.UseVisualStyleBackColor = True
        '
        'Label66
        '
        Me.Label66.AutoSize = True
        Me.Label66.Font = New System.Drawing.Font("Arial Black", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label66.ForeColor = System.Drawing.Color.White
        Me.Label66.Location = New System.Drawing.Point(256, 305)
        Me.Label66.Name = "Label66"
        Me.Label66.Size = New System.Drawing.Size(189, 18)
        Me.Label66.TabIndex = 91
        Me.Label66.Text = "1.8 - 1.9 NETTY CRASHER"
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label13.ForeColor = System.Drawing.Color.White
        Me.Label13.Location = New System.Drawing.Point(466, 98)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(78, 16)
        Me.Label13.TabIndex = 5
        Me.Label13.Text = "Page size »"
        '
        'Button35
        '
        Me.Button35.FlatAppearance.BorderSize = 0
        Me.Button35.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button35.Font = New System.Drawing.Font("Arial Black", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button35.ForeColor = System.Drawing.Color.White
        Me.Button35.Location = New System.Drawing.Point(193, 379)
        Me.Button35.Name = "Button35"
        Me.Button35.Size = New System.Drawing.Size(20, 31)
        Me.Button35.TabIndex = 90
        Me.Button35.Text = "↓"
        Me.Button35.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Button35.UseVisualStyleBackColor = True
        '
        'Button16
        '
        Me.Button16.FlatAppearance.BorderSize = 0
        Me.Button16.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button16.Font = New System.Drawing.Font("Arial Black", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button16.ForeColor = System.Drawing.Color.White
        Me.Button16.Location = New System.Drawing.Point(580, 155)
        Me.Button16.Name = "Button16"
        Me.Button16.Size = New System.Drawing.Size(20, 31)
        Me.Button16.TabIndex = 15
        Me.Button16.Text = "↑"
        Me.Button16.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Button16.UseVisualStyleBackColor = True
        '
        'Button36
        '
        Me.Button36.FlatAppearance.BorderSize = 0
        Me.Button36.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button36.Font = New System.Drawing.Font("Arial Black", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button36.ForeColor = System.Drawing.Color.White
        Me.Button36.Location = New System.Drawing.Point(173, 379)
        Me.Button36.Name = "Button36"
        Me.Button36.Size = New System.Drawing.Size(20, 31)
        Me.Button36.TabIndex = 89
        Me.Button36.Text = "↑"
        Me.Button36.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Button36.UseVisualStyleBackColor = True
        '
        'Label16
        '
        Me.Label16.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label16.ForeColor = System.Drawing.Color.Gray
        Me.Label16.Location = New System.Drawing.Point(539, 164)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(35, 16)
        Me.Label16.TabIndex = 14
        Me.Label16.Text = "10"
        '
        'Label50
        '
        Me.Label50.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label50.ForeColor = System.Drawing.Color.Gray
        Me.Label50.Location = New System.Drawing.Point(119, 388)
        Me.Label50.Name = "Label50"
        Me.Label50.Size = New System.Drawing.Size(56, 16)
        Me.Label50.TabIndex = 88
        Me.Label50.Text = "1500ms"
        '
        'Label12
        '
        Me.Label12.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label12.ForeColor = System.Drawing.Color.Gray
        Me.Label12.Location = New System.Drawing.Point(541, 100)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(33, 14)
        Me.Label12.TabIndex = 6
        Me.Label12.Text = "700"
        '
        'Label51
        '
        Me.Label51.AutoSize = True
        Me.Label51.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label51.ForeColor = System.Drawing.Color.White
        Me.Label51.Location = New System.Drawing.Point(59, 388)
        Me.Label51.Name = "Label51"
        Me.Label51.Size = New System.Drawing.Size(54, 16)
        Me.Label51.TabIndex = 87
        Me.Label51.Text = "Delay »"
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label17.ForeColor = System.Drawing.Color.White
        Me.Label17.Location = New System.Drawing.Point(466, 164)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(67, 16)
        Me.Label17.TabIndex = 13
        Me.Label17.Text = "Packets »"
        '
        'Button37
        '
        Me.Button37.FlatAppearance.BorderSize = 0
        Me.Button37.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button37.Font = New System.Drawing.Font("Arial Black", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button37.ForeColor = System.Drawing.Color.White
        Me.Button37.Location = New System.Drawing.Point(193, 355)
        Me.Button37.Name = "Button37"
        Me.Button37.Size = New System.Drawing.Size(20, 31)
        Me.Button37.TabIndex = 86
        Me.Button37.Text = "↓"
        Me.Button37.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Button37.UseVisualStyleBackColor = True
        '
        'Button13
        '
        Me.Button13.FlatAppearance.BorderSize = 0
        Me.Button13.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button13.Font = New System.Drawing.Font("Arial Black", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button13.ForeColor = System.Drawing.Color.White
        Me.Button13.Location = New System.Drawing.Point(600, 113)
        Me.Button13.Name = "Button13"
        Me.Button13.Size = New System.Drawing.Size(20, 31)
        Me.Button13.TabIndex = 12
        Me.Button13.Text = "↓"
        Me.Button13.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Button13.UseVisualStyleBackColor = True
        '
        'Button38
        '
        Me.Button38.FlatAppearance.BorderSize = 0
        Me.Button38.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button38.Font = New System.Drawing.Font("Arial Black", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button38.ForeColor = System.Drawing.Color.White
        Me.Button38.Location = New System.Drawing.Point(173, 355)
        Me.Button38.Name = "Button38"
        Me.Button38.Size = New System.Drawing.Size(20, 31)
        Me.Button38.TabIndex = 85
        Me.Button38.Text = "↑"
        Me.Button38.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Button38.UseVisualStyleBackColor = True
        '
        'Button11
        '
        Me.Button11.FlatAppearance.BorderSize = 0
        Me.Button11.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button11.Font = New System.Drawing.Font("Arial Black", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button11.ForeColor = System.Drawing.Color.White
        Me.Button11.Location = New System.Drawing.Point(580, 89)
        Me.Button11.Name = "Button11"
        Me.Button11.Size = New System.Drawing.Size(20, 31)
        Me.Button11.TabIndex = 7
        Me.Button11.Text = "↑"
        Me.Button11.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Button11.UseVisualStyleBackColor = True
        '
        'Label52
        '
        Me.Label52.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label52.ForeColor = System.Drawing.Color.Gray
        Me.Label52.Location = New System.Drawing.Point(128, 364)
        Me.Label52.Name = "Label52"
        Me.Label52.Size = New System.Drawing.Size(44, 16)
        Me.Label52.TabIndex = 84
        Me.Label52.Text = "15"
        '
        'Button14
        '
        Me.Button14.FlatAppearance.BorderSize = 0
        Me.Button14.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button14.Font = New System.Drawing.Font("Arial Black", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button14.ForeColor = System.Drawing.Color.White
        Me.Button14.Location = New System.Drawing.Point(580, 113)
        Me.Button14.Name = "Button14"
        Me.Button14.Size = New System.Drawing.Size(20, 31)
        Me.Button14.TabIndex = 11
        Me.Button14.Text = "↑"
        Me.Button14.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Button14.UseVisualStyleBackColor = True
        '
        'Label53
        '
        Me.Label53.AutoSize = True
        Me.Label53.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label53.ForeColor = System.Drawing.Color.White
        Me.Label53.Location = New System.Drawing.Point(59, 364)
        Me.Label53.Name = "Label53"
        Me.Label53.Size = New System.Drawing.Size(67, 16)
        Me.Label53.TabIndex = 83
        Me.Label53.Text = "Packets »"
        '
        'Label14
        '
        Me.Label14.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label14.ForeColor = System.Drawing.Color.Gray
        Me.Label14.Location = New System.Drawing.Point(541, 122)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(33, 16)
        Me.Label14.TabIndex = 10
        Me.Label14.Text = "1"
        '
        'Label57
        '
        Me.Label57.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label57.ForeColor = System.Drawing.Color.Gray
        Me.Label57.Location = New System.Drawing.Point(118, 331)
        Me.Label57.Name = "Label57"
        Me.Label57.Size = New System.Drawing.Size(100, 16)
        Me.Label57.TabIndex = 82
        Me.Label57.Text = "ExploitFixer"
        '
        'Button12
        '
        Me.Button12.FlatAppearance.BorderSize = 0
        Me.Button12.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button12.Font = New System.Drawing.Font("Arial Black", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button12.ForeColor = System.Drawing.Color.White
        Me.Button12.Location = New System.Drawing.Point(600, 89)
        Me.Button12.Name = "Button12"
        Me.Button12.Size = New System.Drawing.Size(20, 31)
        Me.Button12.TabIndex = 8
        Me.Button12.Text = "↓"
        Me.Button12.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Button12.UseVisualStyleBackColor = True
        '
        'Label58
        '
        Me.Label58.AutoSize = True
        Me.Label58.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label58.ForeColor = System.Drawing.Color.White
        Me.Label58.Location = New System.Drawing.Point(59, 331)
        Me.Label58.Name = "Label58"
        Me.Label58.Size = New System.Drawing.Size(53, 16)
        Me.Label58.TabIndex = 81
        Me.Label58.Text = "Mode »"
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label15.ForeColor = System.Drawing.Color.White
        Me.Label15.Location = New System.Drawing.Point(466, 122)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(58, 16)
        Me.Label15.TabIndex = 9
        Me.Label15.Text = "Pages »"
        '
        'Label59
        '
        Me.Label59.AutoSize = True
        Me.Label59.Font = New System.Drawing.Font("Arial Black", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label59.ForeColor = System.Drawing.Color.White
        Me.Label59.Location = New System.Drawing.Point(59, 305)
        Me.Label59.Name = "Label59"
        Me.Label59.Size = New System.Drawing.Size(153, 18)
        Me.Label59.TabIndex = 80
        Me.Label59.Text = "ANTICRASH BYPASS"
        '
        'Button31
        '
        Me.Button31.FlatAppearance.BorderSize = 0
        Me.Button31.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button31.Font = New System.Drawing.Font("Arial Black", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button31.ForeColor = System.Drawing.Color.White
        Me.Button31.Location = New System.Drawing.Point(193, 231)
        Me.Button31.Name = "Button31"
        Me.Button31.Size = New System.Drawing.Size(20, 31)
        Me.Button31.TabIndex = 76
        Me.Button31.Text = "↓"
        Me.Button31.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Button31.UseVisualStyleBackColor = True
        '
        'Button32
        '
        Me.Button32.FlatAppearance.BorderSize = 0
        Me.Button32.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button32.Font = New System.Drawing.Font("Arial Black", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button32.ForeColor = System.Drawing.Color.White
        Me.Button32.Location = New System.Drawing.Point(173, 231)
        Me.Button32.Name = "Button32"
        Me.Button32.Size = New System.Drawing.Size(20, 31)
        Me.Button32.TabIndex = 75
        Me.Button32.Text = "↑"
        Me.Button32.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Button32.UseVisualStyleBackColor = True
        '
        'Label43
        '
        Me.Label43.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label43.ForeColor = System.Drawing.Color.Gray
        Me.Label43.Location = New System.Drawing.Point(119, 240)
        Me.Label43.Name = "Label43"
        Me.Label43.Size = New System.Drawing.Size(56, 16)
        Me.Label43.TabIndex = 74
        Me.Label43.Text = "1500ms"
        '
        'Label44
        '
        Me.Label44.AutoSize = True
        Me.Label44.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label44.ForeColor = System.Drawing.Color.White
        Me.Label44.Location = New System.Drawing.Point(59, 240)
        Me.Label44.Name = "Label44"
        Me.Label44.Size = New System.Drawing.Size(54, 16)
        Me.Label44.TabIndex = 73
        Me.Label44.Text = "Delay »"
        '
        'Button33
        '
        Me.Button33.FlatAppearance.BorderSize = 0
        Me.Button33.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button33.Font = New System.Drawing.Font("Arial Black", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button33.ForeColor = System.Drawing.Color.White
        Me.Button33.Location = New System.Drawing.Point(193, 207)
        Me.Button33.Name = "Button33"
        Me.Button33.Size = New System.Drawing.Size(20, 31)
        Me.Button33.TabIndex = 72
        Me.Button33.Text = "↓"
        Me.Button33.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Button33.UseVisualStyleBackColor = True
        '
        'Button34
        '
        Me.Button34.FlatAppearance.BorderSize = 0
        Me.Button34.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button34.Font = New System.Drawing.Font("Arial Black", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button34.ForeColor = System.Drawing.Color.White
        Me.Button34.Location = New System.Drawing.Point(173, 207)
        Me.Button34.Name = "Button34"
        Me.Button34.Size = New System.Drawing.Size(20, 31)
        Me.Button34.TabIndex = 71
        Me.Button34.Text = "↑"
        Me.Button34.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Button34.UseVisualStyleBackColor = True
        '
        'Label45
        '
        Me.Label45.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label45.ForeColor = System.Drawing.Color.Gray
        Me.Label45.Location = New System.Drawing.Point(128, 216)
        Me.Label45.Name = "Label45"
        Me.Label45.Size = New System.Drawing.Size(39, 16)
        Me.Label45.TabIndex = 70
        Me.Label45.Text = "5"
        '
        'Label46
        '
        Me.Label46.AutoSize = True
        Me.Label46.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label46.ForeColor = System.Drawing.Color.White
        Me.Label46.Location = New System.Drawing.Point(59, 216)
        Me.Label46.Name = "Label46"
        Me.Label46.Size = New System.Drawing.Size(67, 16)
        Me.Label46.TabIndex = 69
        Me.Label46.Text = "Packets »"
        '
        'Label47
        '
        Me.Label47.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label47.ForeColor = System.Drawing.Color.Gray
        Me.Label47.Location = New System.Drawing.Point(118, 190)
        Me.Label47.Name = "Label47"
        Me.Label47.Size = New System.Drawing.Size(100, 16)
        Me.Label47.TabIndex = 68
        Me.Label47.Text = "MVC-FIX"
        '
        'Label48
        '
        Me.Label48.AutoSize = True
        Me.Label48.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label48.ForeColor = System.Drawing.Color.White
        Me.Label48.Location = New System.Drawing.Point(59, 190)
        Me.Label48.Name = "Label48"
        Me.Label48.Size = New System.Drawing.Size(53, 16)
        Me.Label48.TabIndex = 67
        Me.Label48.Text = "Mode »"
        '
        'Label49
        '
        Me.Label49.AutoSize = True
        Me.Label49.Font = New System.Drawing.Font("Arial Black", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label49.ForeColor = System.Drawing.Color.White
        Me.Label49.Location = New System.Drawing.Point(59, 164)
        Me.Label49.Name = "Label49"
        Me.Label49.Size = New System.Drawing.Size(113, 18)
        Me.Label49.TabIndex = 66
        Me.Label49.Text = "MVC CRASHER"
        '
        'Button27
        '
        Me.Button27.FlatAppearance.BorderSize = 0
        Me.Button27.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button27.Font = New System.Drawing.Font("Arial Black", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button27.ForeColor = System.Drawing.Color.White
        Me.Button27.Location = New System.Drawing.Point(390, 231)
        Me.Button27.Name = "Button27"
        Me.Button27.Size = New System.Drawing.Size(20, 31)
        Me.Button27.TabIndex = 65
        Me.Button27.Text = "↓"
        Me.Button27.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Button27.UseVisualStyleBackColor = True
        '
        'Button28
        '
        Me.Button28.FlatAppearance.BorderSize = 0
        Me.Button28.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button28.Font = New System.Drawing.Font("Arial Black", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button28.ForeColor = System.Drawing.Color.White
        Me.Button28.Location = New System.Drawing.Point(370, 231)
        Me.Button28.Name = "Button28"
        Me.Button28.Size = New System.Drawing.Size(20, 31)
        Me.Button28.TabIndex = 64
        Me.Button28.Text = "↑"
        Me.Button28.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Button28.UseVisualStyleBackColor = True
        '
        'Label33
        '
        Me.Label33.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label33.ForeColor = System.Drawing.Color.Gray
        Me.Label33.Location = New System.Drawing.Point(316, 240)
        Me.Label33.Name = "Label33"
        Me.Label33.Size = New System.Drawing.Size(56, 16)
        Me.Label33.TabIndex = 63
        Me.Label33.Text = "1500ms"
        '
        'Label34
        '
        Me.Label34.AutoSize = True
        Me.Label34.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label34.ForeColor = System.Drawing.Color.White
        Me.Label34.Location = New System.Drawing.Point(256, 240)
        Me.Label34.Name = "Label34"
        Me.Label34.Size = New System.Drawing.Size(54, 16)
        Me.Label34.TabIndex = 62
        Me.Label34.Text = "Delay »"
        '
        'Button29
        '
        Me.Button29.FlatAppearance.BorderSize = 0
        Me.Button29.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button29.Font = New System.Drawing.Font("Arial Black", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button29.ForeColor = System.Drawing.Color.White
        Me.Button29.Location = New System.Drawing.Point(390, 207)
        Me.Button29.Name = "Button29"
        Me.Button29.Size = New System.Drawing.Size(20, 31)
        Me.Button29.TabIndex = 61
        Me.Button29.Text = "↓"
        Me.Button29.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Button29.UseVisualStyleBackColor = True
        '
        'Button30
        '
        Me.Button30.FlatAppearance.BorderSize = 0
        Me.Button30.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button30.Font = New System.Drawing.Font("Arial Black", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button30.ForeColor = System.Drawing.Color.White
        Me.Button30.Location = New System.Drawing.Point(370, 207)
        Me.Button30.Name = "Button30"
        Me.Button30.Size = New System.Drawing.Size(20, 31)
        Me.Button30.TabIndex = 60
        Me.Button30.Text = "↑"
        Me.Button30.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Button30.UseVisualStyleBackColor = True
        '
        'Label38
        '
        Me.Label38.AutoSize = True
        Me.Label38.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label38.ForeColor = System.Drawing.Color.Gray
        Me.Label38.Location = New System.Drawing.Point(325, 216)
        Me.Label38.Name = "Label38"
        Me.Label38.Size = New System.Drawing.Size(15, 16)
        Me.Label38.TabIndex = 59
        Me.Label38.Text = "5"
        '
        'Label39
        '
        Me.Label39.AutoSize = True
        Me.Label39.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label39.ForeColor = System.Drawing.Color.White
        Me.Label39.Location = New System.Drawing.Point(256, 216)
        Me.Label39.Name = "Label39"
        Me.Label39.Size = New System.Drawing.Size(67, 16)
        Me.Label39.TabIndex = 58
        Me.Label39.Text = "Packets »"
        '
        'Label40
        '
        Me.Label40.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label40.ForeColor = System.Drawing.Color.Gray
        Me.Label40.Location = New System.Drawing.Point(315, 191)
        Me.Label40.Name = "Label40"
        Me.Label40.Size = New System.Drawing.Size(133, 16)
        Me.Label40.TabIndex = 57
        Me.Label40.Text = "DoubleSolve"
        '
        'Label41
        '
        Me.Label41.AutoSize = True
        Me.Label41.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label41.ForeColor = System.Drawing.Color.White
        Me.Label41.Location = New System.Drawing.Point(256, 191)
        Me.Label41.Name = "Label41"
        Me.Label41.Size = New System.Drawing.Size(53, 16)
        Me.Label41.TabIndex = 56
        Me.Label41.Text = "Mode »"
        '
        'Label42
        '
        Me.Label42.AutoSize = True
        Me.Label42.Font = New System.Drawing.Font("Arial Black", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label42.ForeColor = System.Drawing.Color.White
        Me.Label42.Location = New System.Drawing.Point(256, 165)
        Me.Label42.Name = "Label42"
        Me.Label42.Size = New System.Drawing.Size(103, 18)
        Me.Label42.TabIndex = 55
        Me.Label42.Text = "WE CRASHER"
        '
        'Button23
        '
        Me.Button23.FlatAppearance.BorderSize = 0
        Me.Button23.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button23.Font = New System.Drawing.Font("Arial Black", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button23.ForeColor = System.Drawing.Color.White
        Me.Button23.Location = New System.Drawing.Point(390, 91)
        Me.Button23.Name = "Button23"
        Me.Button23.Size = New System.Drawing.Size(20, 31)
        Me.Button23.TabIndex = 54
        Me.Button23.Text = "↓"
        Me.Button23.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Button23.UseVisualStyleBackColor = True
        '
        'Button24
        '
        Me.Button24.FlatAppearance.BorderSize = 0
        Me.Button24.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button24.Font = New System.Drawing.Font("Arial Black", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button24.ForeColor = System.Drawing.Color.White
        Me.Button24.Location = New System.Drawing.Point(370, 91)
        Me.Button24.Name = "Button24"
        Me.Button24.Size = New System.Drawing.Size(20, 31)
        Me.Button24.TabIndex = 53
        Me.Button24.Text = "↑"
        Me.Button24.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Button24.UseVisualStyleBackColor = True
        '
        'Label24
        '
        Me.Label24.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label24.ForeColor = System.Drawing.Color.Gray
        Me.Label24.Location = New System.Drawing.Point(316, 100)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(56, 16)
        Me.Label24.TabIndex = 52
        Me.Label24.Text = "1500ms"
        '
        'Label25
        '
        Me.Label25.AutoSize = True
        Me.Label25.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label25.ForeColor = System.Drawing.Color.White
        Me.Label25.Location = New System.Drawing.Point(256, 100)
        Me.Label25.Name = "Label25"
        Me.Label25.Size = New System.Drawing.Size(54, 16)
        Me.Label25.TabIndex = 51
        Me.Label25.Text = "Delay »"
        '
        'Button25
        '
        Me.Button25.FlatAppearance.BorderSize = 0
        Me.Button25.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button25.Font = New System.Drawing.Font("Arial Black", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button25.ForeColor = System.Drawing.Color.White
        Me.Button25.Location = New System.Drawing.Point(390, 67)
        Me.Button25.Name = "Button25"
        Me.Button25.Size = New System.Drawing.Size(20, 31)
        Me.Button25.TabIndex = 50
        Me.Button25.Text = "↓"
        Me.Button25.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Button25.UseVisualStyleBackColor = True
        '
        'Button26
        '
        Me.Button26.FlatAppearance.BorderSize = 0
        Me.Button26.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button26.Font = New System.Drawing.Font("Arial Black", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button26.ForeColor = System.Drawing.Color.White
        Me.Button26.Location = New System.Drawing.Point(370, 67)
        Me.Button26.Name = "Button26"
        Me.Button26.Size = New System.Drawing.Size(20, 31)
        Me.Button26.TabIndex = 49
        Me.Button26.Text = "↑"
        Me.Button26.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Button26.UseVisualStyleBackColor = True
        '
        'Label26
        '
        Me.Label26.AutoSize = True
        Me.Label26.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label26.ForeColor = System.Drawing.Color.Gray
        Me.Label26.Location = New System.Drawing.Point(325, 76)
        Me.Label26.Name = "Label26"
        Me.Label26.Size = New System.Drawing.Size(15, 16)
        Me.Label26.TabIndex = 48
        Me.Label26.Text = "5"
        '
        'Label27
        '
        Me.Label27.AutoSize = True
        Me.Label27.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label27.ForeColor = System.Drawing.Color.White
        Me.Label27.Location = New System.Drawing.Point(256, 76)
        Me.Label27.Name = "Label27"
        Me.Label27.Size = New System.Drawing.Size(67, 16)
        Me.Label27.TabIndex = 47
        Me.Label27.Text = "Packets »"
        '
        'Label35
        '
        Me.Label35.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label35.ForeColor = System.Drawing.Color.Gray
        Me.Label35.Location = New System.Drawing.Point(315, 43)
        Me.Label35.Name = "Label35"
        Me.Label35.Size = New System.Drawing.Size(100, 16)
        Me.Label35.TabIndex = 44
        Me.Label35.Text = "TarUltimate"
        '
        'Label36
        '
        Me.Label36.AutoSize = True
        Me.Label36.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label36.ForeColor = System.Drawing.Color.White
        Me.Label36.Location = New System.Drawing.Point(256, 43)
        Me.Label36.Name = "Label36"
        Me.Label36.Size = New System.Drawing.Size(53, 16)
        Me.Label36.TabIndex = 43
        Me.Label36.Text = "Mode »"
        '
        'Label37
        '
        Me.Label37.AutoSize = True
        Me.Label37.Font = New System.Drawing.Font("Arial Black", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label37.ForeColor = System.Drawing.Color.White
        Me.Label37.Location = New System.Drawing.Point(256, 17)
        Me.Label37.Name = "Label37"
        Me.Label37.Size = New System.Drawing.Size(121, 18)
        Me.Label37.TabIndex = 42
        Me.Label37.Text = "FAWE CRASHER"
        '
        'Button19
        '
        Me.Button19.FlatAppearance.BorderSize = 0
        Me.Button19.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button19.Font = New System.Drawing.Font("Arial Black", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button19.ForeColor = System.Drawing.Color.White
        Me.Button19.Location = New System.Drawing.Point(193, 96)
        Me.Button19.Name = "Button19"
        Me.Button19.Size = New System.Drawing.Size(20, 31)
        Me.Button19.TabIndex = 41
        Me.Button19.Text = "↓"
        Me.Button19.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Button19.UseVisualStyleBackColor = True
        '
        'Button20
        '
        Me.Button20.FlatAppearance.BorderSize = 0
        Me.Button20.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button20.Font = New System.Drawing.Font("Arial Black", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button20.ForeColor = System.Drawing.Color.White
        Me.Button20.Location = New System.Drawing.Point(173, 96)
        Me.Button20.Name = "Button20"
        Me.Button20.Size = New System.Drawing.Size(20, 31)
        Me.Button20.TabIndex = 40
        Me.Button20.Text = "↑"
        Me.Button20.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Button20.UseVisualStyleBackColor = True
        '
        'Label20
        '
        Me.Label20.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label20.ForeColor = System.Drawing.Color.Gray
        Me.Label20.Location = New System.Drawing.Point(119, 105)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(56, 16)
        Me.Label20.TabIndex = 39
        Me.Label20.Text = "1500ms"
        '
        'Label21
        '
        Me.Label21.AutoSize = True
        Me.Label21.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label21.ForeColor = System.Drawing.Color.White
        Me.Label21.Location = New System.Drawing.Point(59, 105)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(54, 16)
        Me.Label21.TabIndex = 38
        Me.Label21.Text = "Delay »"
        '
        'Button21
        '
        Me.Button21.FlatAppearance.BorderSize = 0
        Me.Button21.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button21.Font = New System.Drawing.Font("Arial Black", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button21.ForeColor = System.Drawing.Color.White
        Me.Button21.Location = New System.Drawing.Point(193, 73)
        Me.Button21.Name = "Button21"
        Me.Button21.Size = New System.Drawing.Size(20, 31)
        Me.Button21.TabIndex = 37
        Me.Button21.Text = "↓"
        Me.Button21.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Button21.UseVisualStyleBackColor = True
        '
        'Button22
        '
        Me.Button22.FlatAppearance.BorderSize = 0
        Me.Button22.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button22.Font = New System.Drawing.Font("Arial Black", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button22.ForeColor = System.Drawing.Color.White
        Me.Button22.Location = New System.Drawing.Point(173, 73)
        Me.Button22.Name = "Button22"
        Me.Button22.Size = New System.Drawing.Size(20, 31)
        Me.Button22.TabIndex = 36
        Me.Button22.Text = "↑"
        Me.Button22.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Button22.UseVisualStyleBackColor = True
        '
        'Label22
        '
        Me.Label22.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label22.ForeColor = System.Drawing.Color.Gray
        Me.Label22.Location = New System.Drawing.Point(128, 82)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(44, 16)
        Me.Label22.TabIndex = 35
        Me.Label22.Text = "5"
        '
        'Label23
        '
        Me.Label23.AutoSize = True
        Me.Label23.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label23.ForeColor = System.Drawing.Color.White
        Me.Label23.Location = New System.Drawing.Point(59, 82)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(67, 16)
        Me.Label23.TabIndex = 34
        Me.Label23.Text = "Packets »"
        '
        'Label28
        '
        Me.Label28.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label28.ForeColor = System.Drawing.Color.Gray
        Me.Label28.Location = New System.Drawing.Point(128, 43)
        Me.Label28.Name = "Label28"
        Me.Label28.Size = New System.Drawing.Size(110, 16)
        Me.Label28.TabIndex = 25
        Me.Label28.Text = "Zero-IP"
        Me.Label28.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label29
        '
        Me.Label29.AutoSize = True
        Me.Label29.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label29.ForeColor = System.Drawing.Color.White
        Me.Label29.Location = New System.Drawing.Point(59, 43)
        Me.Label29.Name = "Label29"
        Me.Label29.Size = New System.Drawing.Size(69, 16)
        Me.Label29.TabIndex = 24
        Me.Label29.Text = "Payload »"
        '
        'Label32
        '
        Me.Label32.AutoSize = True
        Me.Label32.Font = New System.Drawing.Font("Arial Black", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label32.ForeColor = System.Drawing.Color.White
        Me.Label32.Location = New System.Drawing.Point(59, 17)
        Me.Label32.Name = "Label32"
        Me.Label32.Size = New System.Drawing.Size(130, 18)
        Me.Label32.TabIndex = 21
        Me.Label32.Text = "LOG4J CRASHER"
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(16, Byte), Integer), CType(CType(16, Byte), Integer), CType(CType(16, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(928, 561)
        Me.ControlBox = False
        Me.Controls.Add(Me.CustomPanel)
        Me.Controls.Add(Me.ThemePanel)
        Me.Controls.Add(Me.BotsPanel)
        Me.Controls.Add(Me.OptionsPanel)
        Me.Controls.Add(Me.RenderPanel)
        Me.Controls.Add(Me.PlayerPanel)
        Me.Controls.Add(Me.MovementPanel)
        Me.Controls.Add(Me.KickPanel)
        Me.Controls.Add(Me.ExploitPanel)
        Me.Controls.Add(Me.CrasherPanel)
        Me.Controls.Add(Me.PictureBox2)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow
        Me.Name = "Form1"
        Me.Opacity = 0.0R
        Me.ShowIcon = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.CustomPanel.ResumeLayout(False)
        Me.CustomPanel.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents Button2 As System.Windows.Forms.Button
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents CrashersButton As System.Windows.Forms.Button
    Friend WithEvents Button3 As System.Windows.Forms.Button
    Friend WithEvents Button4 As System.Windows.Forms.Button
    Friend WithEvents Button5 As System.Windows.Forms.Button
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Button7 As System.Windows.Forms.Button
    Friend WithEvents Button6 As System.Windows.Forms.Button
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents PictureBox2 As System.Windows.Forms.PictureBox
    Friend WithEvents CrasherPanel As System.Windows.Forms.Panel
    Friend WithEvents ExploitPanel As System.Windows.Forms.Panel
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Button8 As System.Windows.Forms.Button
    Friend WithEvents KickPanel As System.Windows.Forms.Panel
    Friend WithEvents MovementPanel As System.Windows.Forms.Panel
    Friend WithEvents PlayerPanel As System.Windows.Forms.Panel
    Friend WithEvents RenderPanel As System.Windows.Forms.Panel
    Friend WithEvents OptionsPanel As System.Windows.Forms.Panel
    Friend WithEvents BotsPanel As System.Windows.Forms.Panel
    Friend WithEvents Button9 As System.Windows.Forms.Button
    Friend WithEvents ThemePanel As System.Windows.Forms.Panel
    Friend WithEvents Button10 As System.Windows.Forms.Button
    Friend WithEvents CustomPanel As System.Windows.Forms.Panel
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents Button12 As System.Windows.Forms.Button
    Friend WithEvents Button11 As System.Windows.Forms.Button
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents Button13 As System.Windows.Forms.Button
    Friend WithEvents Button14 As System.Windows.Forms.Button
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents Button15 As System.Windows.Forms.Button
    Friend WithEvents Button16 As System.Windows.Forms.Button
    Friend WithEvents Label16 As System.Windows.Forms.Label
    Friend WithEvents Label17 As System.Windows.Forms.Label
    Friend WithEvents Button17 As System.Windows.Forms.Button
    Friend WithEvents Button18 As System.Windows.Forms.Button
    Friend WithEvents Label18 As System.Windows.Forms.Label
    Friend WithEvents Label19 As System.Windows.Forms.Label
    Friend WithEvents Label28 As System.Windows.Forms.Label
    Friend WithEvents Label29 As System.Windows.Forms.Label
    Friend WithEvents Label32 As System.Windows.Forms.Label
    Friend WithEvents Label54 As System.Windows.Forms.Label
    Friend WithEvents Label55 As System.Windows.Forms.Label
    Friend WithEvents Label56 As System.Windows.Forms.Label
    Friend WithEvents Button31 As System.Windows.Forms.Button
    Friend WithEvents Button32 As System.Windows.Forms.Button
    Friend WithEvents Label43 As System.Windows.Forms.Label
    Friend WithEvents Label44 As System.Windows.Forms.Label
    Friend WithEvents Button33 As System.Windows.Forms.Button
    Friend WithEvents Button34 As System.Windows.Forms.Button
    Friend WithEvents Label45 As System.Windows.Forms.Label
    Friend WithEvents Label46 As System.Windows.Forms.Label
    Friend WithEvents Label47 As System.Windows.Forms.Label
    Friend WithEvents Label48 As System.Windows.Forms.Label
    Friend WithEvents Label49 As System.Windows.Forms.Label
    Friend WithEvents Button27 As System.Windows.Forms.Button
    Friend WithEvents Button28 As System.Windows.Forms.Button
    Friend WithEvents Label33 As System.Windows.Forms.Label
    Friend WithEvents Label34 As System.Windows.Forms.Label
    Friend WithEvents Button29 As System.Windows.Forms.Button
    Friend WithEvents Button30 As System.Windows.Forms.Button
    Friend WithEvents Label38 As System.Windows.Forms.Label
    Friend WithEvents Label39 As System.Windows.Forms.Label
    Friend WithEvents Label40 As System.Windows.Forms.Label
    Friend WithEvents Label41 As System.Windows.Forms.Label
    Friend WithEvents Label42 As System.Windows.Forms.Label
    Friend WithEvents Button23 As System.Windows.Forms.Button
    Friend WithEvents Button24 As System.Windows.Forms.Button
    Friend WithEvents Label24 As System.Windows.Forms.Label
    Friend WithEvents Label25 As System.Windows.Forms.Label
    Friend WithEvents Button25 As System.Windows.Forms.Button
    Friend WithEvents Button26 As System.Windows.Forms.Button
    Friend WithEvents Label26 As System.Windows.Forms.Label
    Friend WithEvents Label27 As System.Windows.Forms.Label
    Friend WithEvents Label35 As System.Windows.Forms.Label
    Friend WithEvents Label36 As System.Windows.Forms.Label
    Friend WithEvents Label37 As System.Windows.Forms.Label
    Friend WithEvents Custom4 As System.Windows.Forms.Panel
    Friend WithEvents Custom3 As System.Windows.Forms.Panel
    Friend WithEvents Custom2 As System.Windows.Forms.Panel
    Friend WithEvents Custom5 As System.Windows.Forms.Panel
    Friend WithEvents Custom1 As System.Windows.Forms.Panel
    Friend WithEvents Button39 As System.Windows.Forms.Button
    Friend WithEvents Button40 As System.Windows.Forms.Button
    Friend WithEvents Label60 As System.Windows.Forms.Label
    Friend WithEvents Label61 As System.Windows.Forms.Label
    Friend WithEvents Button41 As System.Windows.Forms.Button
    Friend WithEvents Button42 As System.Windows.Forms.Button
    Friend WithEvents Label62 As System.Windows.Forms.Label
    Friend WithEvents Label63 As System.Windows.Forms.Label
    Friend WithEvents Label64 As System.Windows.Forms.Label
    Friend WithEvents Label65 As System.Windows.Forms.Label
    Friend WithEvents Label66 As System.Windows.Forms.Label
    Friend WithEvents Button35 As System.Windows.Forms.Button
    Friend WithEvents Button36 As System.Windows.Forms.Button
    Friend WithEvents Label50 As System.Windows.Forms.Label
    Friend WithEvents Label51 As System.Windows.Forms.Label
    Friend WithEvents Button37 As System.Windows.Forms.Button
    Friend WithEvents Button38 As System.Windows.Forms.Button
    Friend WithEvents Label52 As System.Windows.Forms.Label
    Friend WithEvents Label53 As System.Windows.Forms.Label
    Friend WithEvents Label57 As System.Windows.Forms.Label
    Friend WithEvents Label58 As System.Windows.Forms.Label
    Friend WithEvents Label59 As System.Windows.Forms.Label
    Friend WithEvents Button50 As System.Windows.Forms.Button
    Friend WithEvents Button49 As System.Windows.Forms.Button
    Friend WithEvents Button48 As System.Windows.Forms.Button
    Friend WithEvents Button47 As System.Windows.Forms.Button
    Friend WithEvents Button46 As System.Windows.Forms.Button
    Friend WithEvents Button45 As System.Windows.Forms.Button
    Friend WithEvents Button44 As System.Windows.Forms.Button
    Friend WithEvents Button43 As System.Windows.Forms.Button
    Friend WithEvents Button19 As System.Windows.Forms.Button
    Friend WithEvents Button20 As System.Windows.Forms.Button
    Friend WithEvents Label20 As System.Windows.Forms.Label
    Friend WithEvents Label21 As System.Windows.Forms.Label
    Friend WithEvents Button21 As System.Windows.Forms.Button
    Friend WithEvents Button22 As System.Windows.Forms.Button
    Friend WithEvents Label22 As System.Windows.Forms.Label
    Friend WithEvents Label23 As System.Windows.Forms.Label
    Friend WithEvents Button51 As System.Windows.Forms.Button
    Friend WithEvents Custom6 As System.Windows.Forms.Panel
    Friend WithEvents Label69 As System.Windows.Forms.Label
    Friend WithEvents Label67 As System.Windows.Forms.Label
    Friend WithEvents Label68 As System.Windows.Forms.Label

End Class
